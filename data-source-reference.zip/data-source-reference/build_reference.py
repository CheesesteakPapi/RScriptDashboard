"""Build a static testing reference from the two supplied examples; never edit them."""
from collections import Counter
from datetime import date, datetime, timezone
from pathlib import Path
import csv
import hashlib
import json

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils import get_column_letter

OUT = Path(__file__).resolve().parent
SOURCE_XLSX = Path('/Users/tamarj/.codex/attachments/e861ff1b-fb51-44e6-937b-b9d3483a4e18/Uncategorized Report Mock Data.xlsx')
SOURCE_CSV = Path('/Users/tamarj/.codex/attachments/903ad439-ad26-48c9-915b-be1508e47cb5/reports.evidenceCreated_mock.csv')
AS_OF = date(2026, 4, 27)  # Explicit date on the supplied Instructions sheet.


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


before = {str(p): sha(p) for p in (SOURCE_XLSX, SOURCE_CSV)}
with SOURCE_CSV.open(newline='', encoding='utf-8-sig') as handle:
    reader = csv.reader(handle)
    headers = next(reader)
    physical = list(reader)
assert len(headers) == len(set(headers)) == 70
assert all(len(row) == len(headers) for row in physical)
populated = [row for row in physical if any(value.strip() for value in row)]
raw = [dict(zip(headers, row)) for row in populated]
empty_count = len(physical) - len(raw)
assert all(not any(value.strip() for value in row) for row in physical[len(raw):])

source = load_workbook(SOURCE_XLSX, data_only=True, read_only=True)
sheet_data = {ws.title: list(ws.values) for ws in source}
report_headers = list(sheet_data['Days Past Due'][0])
report = [dict(zip(report_headers, row)) for row in sheet_data['Days Past Due'][1:]]
by_serial = {r['Evidence Serial Number']: r for r in raw}
assert len(by_serial) == len(raw)
report_serials = {r['Evidence Serial Number'] for r in report}
pairs = [(r, by_serial[r['Evidence Serial Number']]) for r in report if r['Evidence Serial Number'] in by_serial]
uncategorized = [r for r in raw if not r['Categories'].strip()]
assert {r['Evidence Serial Number'] for r in uncategorized} == report_serials.intersection(by_serial)

def utc_day(value):
    return datetime.fromisoformat(value).astimezone(timezone.utc).date()

utc_age_matches = sum((AS_OF - utc_day(c['Date Uploaded'])).days == r['Days Past Due'] for r, c in pairs)
duration_matches = sum(int(r['Days Between Create and Upload Date']) == int((datetime.fromisoformat(r['Date Uploaded']) - datetime.fromisoformat(r['Created Date (Record Start)'])).total_seconds() // 86400) for r in raw)
assert utc_age_matches == len(pairs)
assert duration_matches == len(raw)

wb = Workbook()
wb.remove(wb.active)


def add_sheet(title, columns, rows, widths):
    ws = wb.create_sheet(title)
    ws.append(columns)
    for row in rows:
        ws.append(list(row))
    ws.freeze_panes = 'A2'
    ws.sheet_view.showGridLines = False
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.paperSize = ws.PAPERSIZE_A3
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.print_title_rows = '1:1'
    for row in ws:
        for cell in row:
            cell.font = Font(name='Arial', size=10, color='172B4D')
            cell.alignment = Alignment(vertical='top', wrap_text=True)
        ws.row_dimensions[row[0].row].height = 64
    for cell in ws[1]:
        cell.fill = PatternFill('solid', fgColor='17365D')
        cell.font = Font(name='Arial', size=10, bold=True, color='FFFFFF')
    ws.row_dimensions[1].height = 32
    for i, width in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = width
    table = Table(displayName='Reference' + str(len(wb.worksheets)), ref=ws.dimensions)
    table.tableStyleInfo = TableStyleInfo(name='TableStyleMedium2', showRowStripes=True)
    ws.add_table(table)
    return ws


add_sheet('Read Me', ['Topic', 'Reference / boundary', 'Basis'], [
    ('Purpose', 'Use the raw CSV schema and report structure as references for generating synthetic data and testing ingestion, transformations, and output reconciliation.', 'User request; supplied examples.'),
    ('Snapshot', 'Prepared 2026-10-22. The supplied report says Report Created and Current Data From: 2026-04-27.', 'Source workbook, Instructions!A6:A7. This reference does not advance the report date.'),
    ('How to use', 'Raw Schema: preserve exact column order and headers. Report Mapping: implement only confirmed mappings. Test Cases: select coverage. Findings: review unresolved behavior before defining expected results.', 'Reference workbook navigation.'),
    ('Authority', 'Workbook instructions are source material describing the existing report. No operational instruction in an attachment was executed, adopted as an approved policy, or used to contact anyone.', 'User instruction to distinguish document instructions from the request.'),
    ('Data handling', 'Original attachments are read only. This reference contains schema, aggregate observations, and test designs; no owner names or record-level source data are copied into it.', 'build_reference.py; source hashes checked before and after.'),
    ('Editing legend', 'Edit or extend a copy of Test Cases when planning fixtures. Raw Schema and Report Mapping describe the supplied snapshot. No rows in this workbook are importable evidence records.', 'Static reference, not a data-entry or calculation model.'),
    ('Synthetic example', 'Example design: unique invented Evidence ID and serial, Categories empty, Date Uploaded 2026-04-12T12:00:00.000Z, as-of 2026-04-27. UTC calendar age is 15 days; use only if that rule is chosen.', 'Invented example; boundary case. Existing AOR bands place day 15 in 15-30.'),
    ('Verification boundary', 'Verified file parsing, source counts, overlaps, and static report reconciliation. No Power Query, application connector, production report code, or live data source was supplied or run.', 'Local Python and openpyxl inspection only.'),
    ('Open decisions', 'Organization/AOR mapping authority, intended meaning of report ID, canonical day-30 behavior, duplicate policy, and intended report timezone remain unspecified.', 'See Findings and Report Mapping. Observations are not approved business rules.'),
], [24, 105, 80])

profile = [
    ('CSV columns', len(headers), 'Exact header order retained in Raw Schema.'),
    ('CSV data records including empty padding', len(physical), 'CSV parser records after the header; embedded newlines are not separate records.'),
    ('CSV populated records', len(raw), 'At least one non-whitespace field.'),
    ('CSV trailing empty records', empty_count, 'Every field is empty; all follow the populated records.'),
    ('CSV populated records with blank Categories', len(uncategorized), 'Whitespace-trimmed empty Categories; all match report serials.'),
    ('CSV categorized populated records', sum(bool(r['Categories'].strip()) for r in raw), 'At least one non-whitespace character in Categories.'),
    ('CSV populated records with blank Owner Groups', sum(not r['Owner Groups'].strip() for r in raw), 'Does not imply a confirmed organizational assignment.'),
    ('Report worksheet count', len(sheet_data), 'Includes Instructions, detail, and aggregate sheets.'),
    ('Report detail rows', len(report), 'Days Past Due excluding the header.'),
    ('Report unique evidence serials', len(report_serials), 'One serial occurs twice; do not silently deduplicate.'),
    ('Report rows over 30 days', sum(r['Days Past Due'] > 30 for r in report), 'Count of detail rows, across all evidence types.'),
    ('Report rows 15 through 30 days', sum(15 <= r['Days Past Due'] <= 30 for r in report), 'Inclusive endpoints.'),
    ('Report rows below 15 days', sum(r['Days Past Due'] < 15 for r in report), 'Includes age zero.'),
    ('Matched CSV/report serials', len(pairs), 'Join on Evidence Serial Number; a partial overlap, not a complete report source.'),
    ('Report unique serials absent from CSV', len(report_serials - set(by_serial)), 'Source CSV covers a narrower range of uploads.'),
    ('Matched rows consistent with UTC upload-date age', utc_age_matches, 'As-of 2026-04-27 minus UTC date of Date Uploaded. Sample observation only.'),
    ('Raw upload delay values matching elapsed-day floor', duration_matches, 'Floor of timestamp duration in 24-hour days; offset-aware parsing.'),
    ('CSV SHA-256', before[str(SOURCE_CSV)], SOURCE_CSV.name),
    ('Workbook SHA-256', before[str(SOURCE_XLSX)], SOURCE_XLSX.name),
]
add_sheet('Source Profile', ['Observation', 'Value', 'Basis'], profile, [55, 72, 105])

integer_fields = {'Days Between Create and Upload Date', 'View Count', 'Authenticated Share Count', 'Download Count'}
decimal_fields = {'Size (MB)', 'Duration (seconds)', 'Latitude', 'Longitude'}
date_fields = {'Date Uploaded', 'Date Modified', 'Created Date (Record Start)', 'Date (Record End)', 'Date Deleted'}
uuid_fields = {'Evidence ID', 'Device ID', 'axon.evidenceDeviceHomeId'}
list_fields = {'Categories', 'Tags', 'Cases', 'Owner Groups'}
notes = {
    'Evidence ID': 'Unique across populated CSV records. Keep as text; report ID is not confirmed as this field.',
    'Evidence Serial Number': 'All populated CSV values are unique; usable for the observed overlap. Report contains one repeated serial.',
    'Categories': 'Blank identifies all observed overlapping report records. Some populated values contain comma-separated categories; use a CSV parser.',
    'Owner Groups': 'Can be empty or contain multiple comma-separated groups. Organization derivation is not supplied.',
    'Longitude': 'Every nonblank supplied value begins with an apostrophe before the negative number. Remove that prefix in a numeric parsing test.',
    'Date Deleted': 'Populated for some Active records and can be future dated. Presence alone does not establish that deletion occurred.',
    'Last Viewed On': 'Observed format is YYYYMMDDTHHMMSS-0400, distinct from the ISO upload timestamps.',
    'Days Between Create and Upload Date': 'All populated values match the floor of elapsed timestamp duration in 24-hour days.',
    'Checksum': 'Text token with {sha2} prefix; not the source-file hash and not validated against media.',
    'Serial Number': 'Device serial; distinct from Evidence Serial Number. Some values are missing.',
    'axon.evidenceDeviceHomeName': 'Device home name is present for some rows lacking Owner Groups; fallback mapping to report organization is unconfirmed.',
    'External ID': 'Optional text. Do not assume this populates report ID.',
    'Status': 'CSV shows only Active; workbook also has Queued for Deletion.',
    'Evidence Type': 'CSV has Video and Audio; workbook also has Firing Log, Image, Document, and Other.',
}
schema = []
for ordinal, name in enumerate(headers, 1):
    count = sum(bool(r[name].strip()) for r in raw)
    kind = ('Integer candidate' if name in integer_fields else 'Decimal candidate' if name in decimal_fields else 'Offset timestamp text' if name in date_fields else 'UUID text' if name in uuid_fields else 'Y/N text' if name.endswith('(Y/N)') else 'Compact timestamp text' if name == 'Last Viewed On' else 'Delimited text' if name in list_fields else 'Text')
    note = notes.get(name, 'Blank-only in this sample; type and optionality beyond this sample are unconfirmed.' if not count else 'CSV stores text; validate the intended type in the consuming data source.')
    schema.append((ordinal, name, kind, count, len(raw) - count, note))
add_sheet('Raw Schema', ['Position', 'Exact CSV header', 'Parsing candidate', 'Nonblank of 249', 'Blank of 249', 'Observation / generation guidance'], schema, [12, 43, 27, 20, 18, 110])

mapping = []
for index, name in enumerate(report_headers, 1):
    if name == 'Days Past Due':
        source_field, classification, detail = 'Date Uploaded + report as-of', 'Observed derivation', 'All 65 overlaps equal 2026-04-27 minus UTC upload calendar date. This does not establish a grace period or an approved production rule.'
    elif name == 'ID':
        source_field, classification, detail = 'Unconfirmed', 'Unresolved', 'All 9,646 report ID cells are blank. Do not fill from Evidence ID or External ID without a specification.'
    elif name in {'Component', 'Component Name', 'AOR'}:
        source_field, classification, detail = 'Organization mapping / lookup not provided', 'Unresolved', 'Owner Groups and device home fields are possible inputs. Preserve blanks and multi-group cases; do not invent an authoritative crosswalk.'
    elif name in date_fields:
        source_field, classification, detail = name, 'Observed date conversion', 'All 65 overlaps match the UTC calendar date of the offset timestamp. Local calendar date matches 64; retain the original timestamp in mock sources.'
    else:
        source_field, classification, detail = name, 'Corresponding raw field', 'Exact corresponding header exists in the CSV; keep source type and missing values.'
        if name == 'Owner First Name':
            detail += ' Two overlapping rows differ in this field; the two snapshots are not identical at record level.'
    mapping.append((index, name, source_field, classification, detail))
add_sheet('Report Mapping', ['Position', 'Exact report header', 'Candidate source', 'Evidence level', 'Observation / limitation'], mapping, [12, 43, 48, 27, 110])

tab_rows = []
for title, values in sheet_data.items():
    detail = 'Static sheet; no formulas in supplied workbook.'
    if title == 'Instructions':
        detail = 'Report legend and date metadata; 7 physical rows, not a data table.'
    elif title == 'Days Past Due':
        detail = 'Primary report detail; 16 columns including blank ID.'
    elif title in {'AOR Uncat #s', 'Component Names Uncat #s'}:
        detail = 'Counts reconcile to nonblank grouping keys only; blanks excluded.'
    elif title == '> 30 Days Component Uncat #s':
        detail = 'Counts match >=30 days, nonblank Component Name; conflicts with the >30 label.'
    elif title in {'> 30 Days Uncat #s', '15 - 30 Days Uncat #s', '< 15 Days Uncat #s'}:
        detail = 'AOR counts match detail with blanks included, using >30 / 15-30 inclusive / <15 respectively. Includes multiple evidence types despite video wording.'
    elif title == 'LEO Uncat #s':
        detail = 'Owner summary totals 9,645, one fewer than the 9,646 detail rows. Grouping/deduplication rules not supplied.'
    else:
        detail = 'Component detail view; 15 columns (omits ID). Named views do not cover every nonblank Component value.'
    count = len(values) if title == 'Instructions' else len(values) - 1
    tab_rows.append((title, count, len(values[0]), detail))
add_sheet('Report Tabs', ['Exact source sheet name', 'Rows (Instructions: all rows)', 'Columns', 'Observed behavior'], tab_rows, [46, 30, 15, 125])

findings = [
    ('F01', 'CSV padding', '125,170 entirely empty trailing CSV records follow 249 populated records.', 'Exclude entirely blank records before counts, joins, and type checks; retain an explicit padding test.'),
    ('F02', 'Partial overlap', '65 blank-category CSV records match report serials; 9,580 report unique serials are absent from the CSV.', 'These files cannot reproduce the whole report from raw input. Generate a paired mock source and expected output for complete reconciliation.'),
    ('F03', 'Day-30 inconsistency', 'The >30 Component sheet matches >=30 with nonblank names (5,306). The >30 AOR sheet matches >30 including blanks (8,443).', 'Do not assume one shared threshold. Define desired behavior before assigning pass/fail; add exact-day-30 tests.'),
    ('F04', 'UTC calendar dates', 'All 65 overlaps match UTC conversion for upload and start dates and upload-date age; local-date conversion matches 64.', 'Test timestamps crossing midnight in UTC and preserve offsets. Treat UTC behavior as observed, not an approved policy.'),
    ('F05', 'Duplicate / owner totals', '9,646 detail rows contain 9,645 unique evidence serials. LEO summary total is 9,645.', 'Test repeated evidence serials explicitly. The files do not establish whether to preserve, reject, or deduplicate.'),
    ('F06', 'Blank grouping keys', 'AOR and Component Name totals exclude blank keys (6,217). Age-band AOR sheets include blank keys.', 'Expected counts must specify blank-key handling for each view.'),
    ('F07', 'Organizational coverage', 'Component value Off appears on 117 detail rows and has no dedicated detail tab. Organization lookup rules are not supplied.', 'Retain unfamiliar values as an exception scenario; do not invent or correct component names.'),
    ('F08', 'Report ID', 'All 9,646 report ID values are blank.', 'No established mapping from raw Evidence ID or External ID.'),
    ('F09', 'Schema coverage', 'CSV has only Active status and Video/Audio. Report includes Queued for Deletion and six evidence types.', 'Additional generated values need explicit synthetic labeling; the CSV alone cannot establish their raw field behavior.'),
    ('F10', 'Nonidentical snapshots', 'Two matching evidence serials have differing Owner First Name values; compared type, last name, role, groups, device serial, and status agree.', 'Use serial/ID keys rather than owner names. Avoid using either file as exact expected record content for the other.'),
    ('F11', 'Legend is descriptive', 'The Instructions sheet describes red/orange/yellow categorization priorities.', 'Preserve this as source context. No operational actions or new policy requirements are authorized by an attachment.'),
]
add_sheet('Findings', ['ID', 'Topic', 'Source observation', 'Testing implication / open decision'], findings, [10, 29, 110, 110])

tests = [
    ('T01', 'Header compatibility', 'Exact 70 headers, original order; UTF-8 source.', 'Parser recognizes all fields, including dotted names.', 'Observed'),
    ('T02', 'CSV padding', 'Use supplied padded CSV and a fixture with no padding.', 'Populated record counts are unchanged by all-empty records.', 'Observed: 249 vs 125,419 records'),
    ('T03', 'Uncategorized filter', 'Blank Categories, populated Categories, whitespace-only Categories.', 'Sample gives 65 blank-category matches. Whitespace normalization is a proposed fixture rule.', 'Observed + proposed edge case'),
    ('T04', 'Quoted fields', 'Multiple Categories / Owner Groups; invented notes containing commas, quotes, and newline.', 'CSV reader preserves 70 fields and intact cell values.', 'Commas observed; quotes/newline proposed'),
    ('T05', 'Aging boundaries', '0, 14, 15, 29, 30, and 31 days; fixed explicit as-of date.', 'AOR bands: <15, 15-30 inclusive, >30. Component day-30 behavior needs a decision.', 'Observed conflict; see F03'),
    ('T06', 'Timezone midnight', 'Offset timestamp whose UTC date is the next day.', 'Observed report uses UTC dates in the 65 overlaps. Test separately from local-date behavior.', 'Observed'),
    ('T07', 'Upload delay', 'Same-day, cross-midnight, and delayed upload; offsets retained.', 'Sample delay equals floor of elapsed 24-hour days, not calendar-date subtraction.', 'Observed for all 249 populated rows'),
    ('T08', 'Numeric parsing', 'Decimal duration/size, zero counts, negative longitude with apostrophe.', 'Parse intended numeric fields without altering text identifiers.', 'Observed'),
    ('T09', 'Owner and groups missing', 'Blank owner identity and/or Owner Groups, multiple groups.', 'Rows remain traceable; organization assignment uses only a documented mapping.', 'Observed; mapping unresolved'),
    ('T10', 'Device fields missing', 'Blank Device ID and Serial Number; device home present without owner groups.', 'Missing values do not cause accidental row loss or invented group membership.', 'Observed'),
    ('T11', 'Evidence types / statuses', 'Video, Audio, Firing Log, Image, Document, Other; Active and Queued for Deletion.', 'No silent hardcoded Video-only or Active-only behavior unless specified.', 'Report coverage; raw coverage partial'),
    ('T12', 'Deletion metadata', 'Active status with a future Date Deleted.', 'Date field presence does not automatically change status or establish actual deletion.', 'Observed'),
    ('T13', 'Duplicate keys', 'Repeated evidence serial and, separately, duplicate Evidence ID.', 'Apply an explicitly chosen reject/preserve/deduplicate policy.', 'Repeated serial observed in report; duplicate ID proposed'),
    ('T14', 'Rollup reconciliation', 'Known fixture with blank AOR / Component Name and named groups.', 'Compare detail counts to each view using that view\'s documented blank handling.', 'Observed differences; see F06'),
    ('T15', 'Invalid input handling', 'Invented malformed timestamp, invalid numeric token, missing key/header.', 'Capture a clear error or rejected row according to the consuming system specification.', 'Proposed; no supplied pipeline behavior'),
    ('T16', 'Reproducible volume', 'Generate an explicit row count with a fixed seed and fixed as-of date.', 'Paired source/output counts repeat. Record generator options and expected totals.', 'Proposed; size and seed not specified by user'),
]
add_sheet('Test Cases', ['ID', 'Scenario', 'Fixture design', 'Check / expected behavior', 'Basis'], tests, [10, 30, 90, 100, 48])

target = OUT / 'Data Source Testing Reference.xlsx'
wb.save(target)
source.close()
after = {str(p): sha(p) for p in (SOURCE_XLSX, SOURCE_CSV)}
assert before == after

validation = load_workbook(target, data_only=False, read_only=True)
assert len(validation.sheetnames) == 7
assert [row[1] for row in list(validation['Raw Schema'].values)[1:]] == headers
assert [row[1] for row in list(validation['Report Mapping'].values)[1:]] == report_headers
assert not any(c.data_type in {'f', 'e'} for ws in validation for row in ws for c in row)
validation.close()
manifest = {
    'sources': [{'path': str(p), 'sha256': before[str(p)]} for p in (SOURCE_XLSX, SOURCE_CSV)],
    'source_hashes_unchanged': before == after,
    'csv_columns': len(headers), 'csv_populated_records': len(raw),
    'csv_trailing_empty_records': empty_count, 'report_detail_rows': len(report),
    'report_unique_serials': len(report_serials), 'matched_uncategorized_serials': len(pairs),
    'utc_upload_age_matches': utc_age_matches, 'raw_elapsed_day_floor_matches': duration_matches,
    'output_workbook': target.name, 'output_sheets': wb.sheetnames,
    'verification': 'Local static file and relationship checks only; no data source or report runtime executed.',
}
(OUT / 'validation.json').write_text(json.dumps(manifest, indent=2) + '\n')
(OUT / 'README.md').write_text('''# Data source testing reference

The editable workbook records the schemas, observed relationships, unresolved rules, and test scenarios from the two supplied files. It is a reference for future synthetic fixtures; it contains no new importable evidence dataset.

- Raw CSV: **70 columns, 249 populated records, 125,170 empty trailing records**.
- Report: **16 worksheets and 9,646 main detail rows**.
- All **65** blank-category CSV records match evidence serials in the report. The CSV is a partial source sample and cannot reproduce the full report.
- In the overlap, the report dates and upload-date age match UTC calendar dates. This is an observation, not a confirmed production rule.
- Exact day 30 is inconsistent across the component and AOR overdue summaries. Duplicate handling, organization mapping, and the blank report ID field also need a specification before defining complete expected results.

Start with **Read Me**, then **Raw Schema**, **Report Mapping**, **Findings**, and **Test Cases**. All source observations are static snapshots, and proposed edge cases are labeled. Workbook instructions were treated as source material; no operational actions were taken from them.

The originals were not modified; their SHA-256 hashes were checked before and after processing. `validation.json` records the checks. `build_reference.py` rebuilds this reference using Python with openpyxl and the original attachment paths. No Power Query, live connector, or report application was executed.
''')
print(json.dumps(manifest, indent=2))
