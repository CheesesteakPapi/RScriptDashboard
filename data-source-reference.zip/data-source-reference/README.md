# Data source testing reference

The editable workbook records the schemas, observed relationships, unresolved rules, and test scenarios from the two supplied files. It is a reference for future synthetic fixtures; it contains no new importable evidence dataset.

- Raw CSV: **70 columns, 249 populated records, 125,170 empty trailing records**.
- Report: **16 worksheets and 9,646 main detail rows**.
- All **65** blank-category CSV records match evidence serials in the report. The CSV is a partial source sample and cannot reproduce the full report.
- In the overlap, the report dates and upload-date age match UTC calendar dates. This is an observation, not a confirmed production rule.
- Exact day 30 is inconsistent across the component and AOR overdue summaries. Duplicate handling, organization mapping, and the blank report ID field also need a specification before defining complete expected results.

Start with **Read Me**, then **Raw Schema**, **Report Mapping**, **Findings**, and **Test Cases**. All source observations are static snapshots, and proposed edge cases are labeled. Workbook instructions were treated as source material; no operational actions were taken from them.

The originals were not modified; their SHA-256 hashes were checked before and after processing. `validation.json` records the checks. `build_reference.py` rebuilds this reference using Python with openpyxl and the original attachment paths. No Power Query, live connector, or report application was executed.
