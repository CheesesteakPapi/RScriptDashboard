# Dataverse token reader template

Use the existing token publisher. Add this reader to the Power Automate acquisition flow before its Axon reporting requests. The report workbook and Power BI consume the resulting SharePoint report data.

This is a template, not a deployed flow. All connection settings remain editable. It contains no token value or client secret.

## Supplied settings

| Setting | Template value |
|---|---|
| Dataverse environment | `https://icewbc-dev.crm9.dynamics.com` |
| API version | `v9.2` |
| Table logical name | `bwc_axonauthcache` |
| Entity set | `bwc_axonauthcaches` |
| Access-token property | `AccessToken` |
| Expiry property | `ExpiresAtUtc` |
| Authorization scheme | `Bearer` |
| Publication contract | One current Axon token row |
| Proposed freshness margin | 120 seconds, editable |

The two property names are used exactly as supplied. If the Dataverse connector exposes different logical names, replace the names in Select columns and the expressions below. The token field is assumed to contain the raw token, without the `Bearer ` prefix. The expiry is assumed to be an ISO 8601 timestamp with UTC or an explicit offset. These assumptions have not been checked against a live connection.

## Reader placement

In the combined walkthrough, run the entire reader/guard block at the start of each Created or Updated page iteration. Each next page therefore obtains the current published token. Its one permitted 401 retry uses the reread action output for the same page. This avoids carrying a stale initial action output into later pages. Use distinct action names for the Updated loop, as described in the combined guide.

### Failure handling when the reader is inside a page loop

Initialize RunFailed=false and FailureReason at the flow's top level. On an invalid token/row/expiry or unrecoverable HTTP result, set those variables inside the loop. Exit through the loop condition; use the Failed Terminate action outside the loop. Do not place Terminate inside a loop. In the instructions below, “fail acquisition” means this flag/exit/outside-gate pattern when used inside a page loop.

## 1. Read the published row

Add **Microsoft Dataverse → List rows**, name it `List_Published_Axon_Token`, and bind your existing Dataverse connection to the supplied environment.

| Action setting | Value |
|---|---|
| Table | Select the table corresponding to `bwc_axonauthcache` |
| Select columns | `AccessToken,ExpiresAtUtc` |
| Row count | `2` |
| Filter rows | Empty, under the confirmed single-current-row contract |

Use secure inputs/outputs for this token-bearing action and downstream requests carrying Authorization. There is no new token-request POST and no client-secret parameter.

## 2. Require exactly one result

Add a Condition before accessing `first(...)`:

```text
equals(length(body('List_Published_Axon_Token')?['value']), 1)
```

Only its Yes branch continues. Zero or two returned rows terminates acquisition as failed, preserving the previous published report. Requesting two rows makes an unexpected second row detectable; `$top=1` would hide it.

## 3. Check token and expiry

Inside the one-row branch, first require a nonempty token:

```text
not(empty(trim(coalesce(first(body('List_Published_Axon_Token')?['value'])?['AccessToken'], ''))))
```

Then require a nonempty expiry:

```text
not(empty(first(body('List_Published_Axon_Token')?['value'])?['ExpiresAtUtc']))
```

Then check freshness in a guarded Scope:

```text
greater(
  ticks(first(body('List_Published_Axon_Token')?['value'])?['ExpiresAtUtc']),
  ticks(addSeconds(utcNow(), 120))
)
```

A missing token, missing expiry, expired/near-expiry token, or timestamp parse failure takes the failed-acquisition path. The existing publisher remains responsible for renewal. Use separate Conditions in this order so empty or invalid values are not evaluated prematurely.

## 4. Use the token in the existing Axon request

Set the HTTP GET action's Authorization header using this Expression:

```text
concat('Bearer ', trim(first(body('List_Published_Axon_Token')?['value'])?['AccessToken']))
```

Designer Expression fields use the expression without a leading `@`. The companion JSON reference includes `@` for code-view representation.

Keep the token in the secured action output and request header. Do not add it to worksheet tables, Power BI outputs, exported evidence files, or diagnostic logs.

## 5. Use bounded 401 recovery

On the first Axon report-request 401 for a page, re-read the published row and repeat the checks. Retry the same page once if a usable replacement token is available. A missing replacement or second 401 fails the run. A 403 fails authorization directly. Preserve the existing pagination, retry controls, working-copy processing, and successful-publication watermark rules.

## Files

- `dataverse-token-settings.template.json`: supplied bindings and editable assumptions.
- `dataverse-token-flow.template.json`: action configuration and expression reference; not an importable Power Automate solution or flow package.
- `Dataverse Token Integration.md`: broader integration rationale and test-case design.

No live Dataverse access or Axon request is required to use or edit this template. No live connection was configured in creating it.
