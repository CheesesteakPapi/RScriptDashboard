# Start here

Read **Guide.pdf** for the printable walkthrough or **Guide.md** for editable instructions and copyable expressions.

1. **Local CSV testing:** open `Power Query Workbook/Power Query Setup Template.xlsx`, set DataFolder, and install the 21 supplied M queries using the guide and Query Catalog. This is a setup workbook with no queries installed. `Expected Uncategorized Report.xlsx` is a static reference, not an automatically refreshed report.
2. **Cloud token reader:** use the three files in `Dataverse Token Reader/` to create the actions manually in Power Automate. The JSON is not an importable flow. Connections remain unconfigured.
3. **Scheduled cloud report:** use the separate RScriptDashboard `automation/report-template.xlsx` with its two Office Scripts. The guide links those files and explains why a cloud flow cannot simply refresh the local CSV Power Query workbook.

The clean setup file opened normally in local Excel. Native CSV query refresh has not passed acceptance; a Mac authoring attempt requested a gateway. The guide documents Windows Excel setup menus and the separate desktop-free cloud route. Live Dataverse, SharePoint, Power Automate, and Power BI execution are unverified.

The local fixture uses >30 / 15-30 and has 757 uncategorized records. The cloud repository uses 30+ / 15-29 and a different 8-record smoke fixture. Their expected counts are not interchangeable.

`verification.json` records the verification boundary. `SHA256SUMS.txt` lists packaged file hashes, excluding itself. No token value or client secret is included.
