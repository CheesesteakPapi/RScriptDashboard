EvidenceModel[Tables][OFTP]
