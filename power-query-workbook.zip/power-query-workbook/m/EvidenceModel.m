let
    // All report and test outputs derive from this model. Helpers are local to avoid installing macros.
    SettingsTable = Excel.CurrentWorkbook(){[Name="tblSettings"]}[Content],
    TextValue = (x as any) as text => if x = null then "" else Text.From(x, "en-US"),
    Setting = (key as text) as text => TextValue(Table.SelectRows(SettingsTable, each [Parameter] = key){0}[Value]),
    Folder = Text.TrimEnd(Setting("DataFolder"), {"/", "\"}),
    Separator = if Text.Contains(Folder, "\") then "\" else "/",
    Path = (relative as text) as text => Folder & Separator & Text.Replace(relative, "/", Separator),
    SourceFile = Setting("SourceFile"),
    AsOf = Date.FromText(Setting("AsOfDate"), [Format="yyyy-MM-dd", Culture="en-US"]),
    FixtureChecks = Text.Upper(Setting("RunFixtureChecks")) = "TRUE",
    ExpectedRows = Number.FromText(Setting("ExpectedSourceRows"), "en-US"),
    ExpectedUncat = Number.FromText(Setting("ExpectedUncategorizedRows"), "en-US"),
    Headers = {"Evidence ID","Status","Title","External ID","Description","Evidence Group","Date Uploaded","Date Modified","Created Date (Record Start)","Date (Record End)","Date Deleted","Days Between Create and Upload Date","Evidence Type","Flag (Y/N)","Content Type","Size (MB)","Duration (seconds)","Owner Rank","Owner First Name","Owner Last Name","Owner Badge ID","Owner Role","Owner Evidence Group","Owner Groups","Updated By Rank","Updated By First Name","Updated By Last Name","Updated By Badge ID","Updated By Role","Deleted By Rank","Deleted By First Name","Deleted By Last Name","Deleted By Badge ID","Deleted By Role","Uploaded By Rank","Uploaded By First Name","Uploaded By Last Name","Uploaded By Badge ID","Uploaded By Role","Latitude","Longitude","Device ID","Serial Number","Notes","Categories","Tags","Cases","View Count","Last Viewed On","Reassigned (Y/N)","Authenticated Share Count","Download Count","Deletion Type","Checksum","Restricted (Y/N)","Evidence Internal ACL Users","Evidence Internal ACL Groups","Evidence External ACL Users","Evidence External ACL Groups","Evidence Partner Agencies","Case Partner Agencies","Evidence Serial Number","hsi_incident_number","axon.evidenceDeviceHomeId","icm_case_number","eagle_event_number","icm_op_plan_number","sen_number","axon.evidenceDeviceHomeName","foia_case_number"},
    ReportHeaders = {"Days Past Due","Evidence Serial Number","ID","Evidence Type","Owner First Name","Owner Last Name","Owner Role","Owner Groups","Serial Number","Created Date (Record Start)","Date Uploaded","Days Between Create and Upload Date","Component","Component Name","AOR","Status"},
    OwnerHeaders = {"Owner First Name","Owner Last Name","Owner Role","Owner Groups","Component","Component Name","AOR"},
    GroupMap = Table.TransformColumns(Excel.CurrentWorkbook(){[Name="tblOrgMap"]}[Content], List.Transform({"Owner Group", "Component", "Component Name", "AOR"}, (h) => {h, TextValue, type text})),
    MapKeysValid = Table.RowCount(GroupMap) = List.Count(List.Distinct(GroupMap[Owner Group])) and not List.Contains(GroupMap[Owner Group], ""),
    NowUTC = Text.From(DateTimeZone.FixedUtcNow(), "en-US"),

    ReadCsv = (file as text) as record =>
        let
            Attempt = try Table.Buffer(Csv.Document(File.Contents(Path(file)), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv])),
            Promoted = if Attempt[HasError] then #table(Headers, {}) else Table.PromoteHeaders(Attempt[Value], [PromoteAllScalars=true]),
            SchemaOK = not Attempt[HasError] and Table.ColumnNames(Promoted) = Headers,
            Data = if SchemaOK then Table.TransformColumns(Promoted, List.Transform(Headers, (h) => {h, TextValue, type text})) else #table(Headers, {}),
            Indexed = Table.AddIndexColumn(Data, "CSV Record", 1, 1, Int64.Type),
            Populated = Table.SelectRows(Indexed, (r) => List.AnyTrue(List.Transform(Headers, (h) => Text.Trim(Record.Field(r,h)) <> ""))),
            Blanks = Table.RowCount(Indexed) - Table.RowCount(Populated),
            Message = if Attempt[HasError] then try Attempt[Error][Message] otherwise "File could not be read" else if not SchemaOK then "Exact header names and order do not match the 70-column contract" else ""
        in [SchemaOK=SchemaOK, ErrorCode=if Attempt[HasError] then "FILE_READ_ERROR" else if not SchemaOK then "SCHEMA_MISMATCH" else "", ErrorMessage=Message, Data=Table.Buffer(Populated), BlankRows=Blanks],

    ParseNumber = (x as any) as nullable number =>
        let n = try Number.FromText(TextValue(x), "en-US") otherwise null
        in if n = null then null else if Number.IsNaN(n) or n = #infinity or n = -#infinity then null else n,
    ParseStamp = (x as any) as nullable datetimezone =>
        let s = TextValue(x), len = Text.Length(s),
            HasZone = Text.EndsWith(Text.Upper(s), "Z") or (len >= 6 and List.Contains({"+", "-"}, Text.Middle(s,len-6,1)) and Text.Middle(s,len-3,1) = ":")
        in if not HasZone then null else try DateTimeZone.FromText(s, [Culture="en-US"]) otherwise null,
    RowErrors = (r as record) as text =>
        let
            Get = (h as text) => Record.Field(r,h),
            Upload = ParseStamp(Get("Date Uploaded")), Start = ParseStamp(Get("Created Date (Record Start)")),
            NumFields = {{"Size (MB)","INVALID_SIZE_MB"},{"Duration (seconds)","INVALID_DURATION"},{"View Count","INVALID_VIEW_COUNT"},{"Download Count","INVALID_DOWNLOAD_COUNT"},{"Authenticated Share Count","INVALID_SHARE_COUNT"},{"Days Between Create and Upload Date","INVALID_UPLOAD_DELAY"}},
            IntFields = {"View Count","Download Count","Authenticated Share Count","Days Between Create and Upload Date"},
            NumErrors = List.Transform(NumFields, (pair) => let n=ParseNumber(Get(pair{0})) in if n=null then pair{1} else if n<0 or (List.Contains(IntFields,pair{0}) and Number.RoundDown(n)<>n) then pair{1} else null),
            StampErrors = List.Transform({{"Date Uploaded","INVALID_DATE_UPLOADED"},{"Created Date (Record Start)","INVALID_RECORD_START"},{"Date Modified","INVALID_DATE_MODIFIED"}}, (pair) => if ParseStamp(Get(pair{0}))=null then pair{1} else null),
            OptionalErrors = List.Transform({"Date (Record End)","Date Deleted"}, (h) => if Text.Trim(Get(h))<>"" and ParseStamp(Get(h))=null then "INVALID_OPTIONAL_TIMESTAMP" else null),
            FlagErrors = List.Transform({"Flag (Y/N)","Restricted (Y/N)","Reassigned (Y/N)"}, (h) => if List.Contains({"Y","N"},Get(h)) then null else "INVALID_YN_FLAG"),
            Delay = ParseNumber(Get("Days Between Create and Upload Date")),
            CorrelationErrors = if Upload=null or Start=null then {} else {if Upload<Start then "UPLOAD_BEFORE_START" else null, if Delay=null then null else if Number.RoundDown(Duration.TotalDays(Upload-Start))<>Delay then "UPLOAD_DELAY_MISMATCH" else null},
            Errors = {if Text.Trim(Get("Evidence ID"))="" then "MISSING_EVIDENCE_ID" else null, if Text.Trim(Get("Evidence Serial Number"))="" then "MISSING_EVIDENCE_SERIAL" else null} & NumErrors & StampErrors & OptionalErrors & FlagErrors & CorrelationErrors
        in Text.Combine(List.RemoveNulls(Errors), "|"),

    Process = (read as record) as record =>
        let
            Checked = Table.AddColumn(read[Data], "RowErrors", each RowErrors(_), type text),
            Valid = Table.SelectRows(Checked, each [RowErrors]=""),
            // Reserve keys only when a record is accepted: a rejected duplicate cannot block a later valid row.
            Decisions = List.Accumulate(Table.ToRecords(Table.Sort(Valid,{{"CSV Record",Order.Ascending}})),[IDs=[],Serials=[],Rows={}],(state,r)=>
                let ID=r[Evidence ID], Serial=r[Evidence Serial Number],
                    Message=Text.Combine(List.RemoveNulls({if Record.HasFields(state[IDs],ID) then "DUPLICATE_EVIDENCE_ID" else null,if Record.HasFields(state[Serials],Serial) then "DUPLICATE_EVIDENCE_SERIAL" else null}),"|"),
                    Keep=Message=""
                in [IDs=if Keep then Record.AddField(state[IDs],ID,true) else state[IDs],Serials=if Keep then Record.AddField(state[Serials],Serial,true) else state[Serials],Rows={{r[CSV Record],Message}}&state[Rows]]),
            DecisionTable=#table(type table [#"CSV Record"=Int64.Type,RejectionReason=text],List.Reverse(Decisions[Rows])),
            Duplicates=Table.ExpandTableColumn(Table.NestedJoin(Valid,{"CSV Record"},DecisionTable,{"CSV Record"},"_decision",JoinKind.LeftOuter),"_decision",{"RejectionReason"}),
            Accepted = Table.Buffer(Table.SelectColumns(Table.SelectRows(Duplicates,each [RejectionReason]=""),{"CSV Record"}&Headers)),
            Bad = Table.RenameColumns(Table.SelectColumns(Table.SelectRows(Checked,each [RowErrors]<>""),{"CSV Record"}&Headers&{"RowErrors"}),{{"RowErrors","RejectionReason"}}),
            DuplicateBad = Table.SelectColumns(Table.SelectRows(Duplicates,each [RejectionReason]<>""),{"CSV Record"}&Headers&{"RejectionReason"}),
            Rejected = Table.Sort(Table.Combine({Bad,DuplicateBad}),{{"CSV Record",Order.Ascending}})
        in [Accepted=Accepted,Rejected=Rejected,Read=read],

    ResolveOrg = (groups as text) as record =>
        let Tokens=List.Select(List.Transform(Text.Split(groups,","),Text.Trim),each _<>""),
            Matches=List.Transform(Tokens,(g)=>Table.SelectRows(GroupMap,each [Owner Group]=g)),
            Complete=MapKeysValid and List.AllTrue(List.Transform(Matches,each Table.RowCount(_)=1)),
            Targets=if Complete then List.Distinct(List.Transform(Matches,(t)=>{t{0}[Component],t{0}[Component Name],t{0}[AOR]})) else {},
            Mapped=List.Count(Tokens)>0 and Complete and List.Count(Targets)=1,
            Org=if Mapped then Targets{0} else {"","",""},
            Reason=if not MapKeysValid then "invalid crosswalk keys" else if List.Count(Tokens)=0 then "blank groups" else if not Complete then "unmapped group" else if List.Count(Targets)<>1 then "conflicting organizations" else "mapped"
        in [Component=Org{0},#"Component Name"=Org{1},AOR=Org{2},#"Mapping Result"=Reason],
    MainRead = ReadCsv(SourceFile),
    Main = Process(MainRead),
    WithOrg = Table.AddColumn(Main[Accepted],"_org",each ResolveOrg([Owner Groups]),type record),
    Mapped = Table.Buffer(Table.ExpandRecordColumn(WithOrg,"_org",{"Component","Component Name","AOR","Mapping Result"})),
    WithAge = Table.AddColumn(Mapped,"Days Past Due",each Duration.Days(AsOf-Date.From(DateTimeZone.ToUtc(ParseStamp([Date Uploaded])))),Int64.Type),
    WithID = Table.AddColumn(WithAge,"ID",each "",type text),
    Uncat = Table.SelectRows(WithID,each Text.Trim([Categories])=""),
    ConvertedDates = Table.TransformColumns(Uncat,List.Transform({"Created Date (Record Start)","Date Uploaded"},(h)=>{h,each Date.ToText(Date.From(DateTimeZone.ToUtc(ParseStamp(_))),[Format="yyyy-MM-dd",Culture="en-US"]),type text})),
    Detail = Table.Buffer(Table.Sort(Table.TransformColumnTypes(Table.SelectColumns(ConvertedDates,ReportHeaders),{{"Days Past Due",Int64.Type},{"Days Between Create and Upload Date",Int64.Type}},"en-US"),{{"Days Past Due",Order.Descending},{"Evidence Serial Number",Order.Ascending}})),
    // Invalid file schemas produce a visible refresh error rather than a silently empty report.
    RequireSource = (t as table) as table => if MainRead[SchemaOK] then t else error Error.Record(MainRead[ErrorCode],MainRead[ErrorMessage],[File=Path(SourceFile)]),
    ComponentView = (component as text) as table => Table.RemoveColumns(Table.SelectRows(Detail,each [Component]=component),{"ID"}),
    Rollup = (input as table, key as text, heading as text, keepBlank as logical) as table =>
        let Selection=if keepBlank then input else Table.SelectRows(input,(r)=>Record.Field(r,key)<>""),
            Groups=Table.Group(Selection,{key},{{heading,each Table.RowCount(_),Int64.Type}})
        in Table.Sort(Groups,{{heading,Order.Descending},{key,Order.Ascending}}),
    Critical = Table.SelectRows(Detail,each [Days Past Due]>30),
    Overdue = Table.SelectRows(Detail,each [Days Past Due]>=15 and [Days Past Due]<=30),
    Recent = Table.SelectRows(Detail,each [Days Past Due]<15),
    OwnerCounts = Table.Group(Detail,OwnerHeaders,{{"Total Uncategorized Items",each Table.RowCount(_),Int64.Type}}),
    Owners = Table.Sort(Table.ReorderColumns(OwnerCounts,{"Total Uncategorized Items"}&OwnerHeaders),{{"Total Uncategorized Items",Order.Descending}}&List.Transform(OwnerHeaders,each {_,Order.Ascending})),
    Tables = [
        DaysPastDue=RequireSource(Detail), HSI=RequireSource(ComponentView("HSI")), ERO=RequireSource(ComponentView("ERO")), FLETC=RequireSource(ComponentView("FLETC")), FOIA=RequireSource(ComponentView("FOIA")),
        OPR=RequireSource(ComponentView("Office of Professional Responsibility")), OFTP=RequireSource(ComponentView("Office of Firearms and Tactical Programs")), Blanks=RequireSource(ComponentView("")),
        AOR=RequireSource(Rollup(Detail,"AOR","Total Uncategorized Items",false)), ComponentNames=RequireSource(Rollup(Detail,"Component Name","Total Uncategorized Items",false)),
        CriticalComponents=RequireSource(Rollup(Critical,"Component Name","Total Uncategorized Items",false)),
        CriticalAOR=RequireSource(Rollup(Critical,"AOR","Number of Critically Overdue Uncategorized Videos",true)),
        OverdueAOR=RequireSource(Rollup(Overdue,"AOR","Number of Overdue Uncategorized Videos",true)),
        RecentAOR=RequireSource(Rollup(Recent,"AOR","Number of Uncategorized Videos",true)), LEO=RequireSource(Owners)
    ],
    Exceptions = Table.SelectColumns(Table.SelectRows(Mapped,each [Mapping Result]<>"mapped"),{"CSV Record","Evidence ID","Evidence Serial Number","Owner Groups","Mapping Result"}),

    TestSpecs = #table(type table [File=text,ExpectedAccepted=Int64.Type,ExpectedRejected=Int64.Type,ExpectedEmpty=Int64.Type,ExpectedError=text],{
        {"invalid_timestamp.csv",1,1,0,"INVALID_DATE_UPLOADED"},{"invalid_numeric.csv",1,1,0,"INVALID_SIZE_MB"},{"missing_evidence_id.csv",1,1,0,"MISSING_EVIDENCE_ID"},
        {"duplicate_evidence_id.csv",1,1,0,"DUPLICATE_EVIDENCE_ID"},{"duplicate_evidence_serial.csv",1,1,0,"DUPLICATE_EVIDENCE_SERIAL"},
        {"missing_required_header.csv",0,0,0,"SCHEMA_MISMATCH"},{"padded_valid_input.csv",1000,0,40,""}
    }),
    RunTest = (spec as record) as record =>
        let R=ReadCsv("test-inputs/"&spec[File]), P=Process(R), A=Table.RowCount(P[Accepted]), Rej=Table.RowCount(P[Rejected]),
            Codes=if not R[SchemaOK] then R[ErrorCode] else Text.Combine(List.Sort(List.Distinct(P[Rejected][RejectionReason])),"|"),
            IsGood=A=spec[ExpectedAccepted] and Rej=spec[ExpectedRejected] and R[BlankRows]=spec[ExpectedEmpty] and Codes=spec[ExpectedError]
        in [File=spec[File],#"Accepted Rows"=A,#"Rejected Rows"=Rej,#"Empty Rows"=R[BlankRows],#"Error Code"=Codes,Status=if IsGood then "PASS" else "FAIL",#"Refreshed UTC"=NowUTC],
    TestResults = if FixtureChecks then Table.FromRecords(List.Transform(Table.ToRecords(TestSpecs),RunTest)) else #table({"File","Accepted Rows","Rejected Rows","Empty Rows","Error Code","Status","Refreshed UTC"},{{"Fixture checks disabled",0,0,0,"","SKIPPED",NowUTC}}),
    Anchor = (serial as text) as nullable record => try Table.SelectRows(WithID,each [Evidence Serial Number]=serial){0} otherwise null,
    RawAnchor = (serial as text) as nullable record => try Table.SelectRows(Main[Accepted],each [Evidence Serial Number]=serial){0} otherwise null,
    Safe = (action as function) as logical => try action() otherwise false,
    Check = (id as text, scenario as text, expected as any, actual as any, pass as logical, detail as text, fixture as logical) as record =>
        [#"Test ID"=id,Scenario=scenario,Expected=TextValue(expected),Actual=TextValue(actual),Status=if fixture and not FixtureChecks then "SKIPPED" else if pass then "PASS" else "FAIL",Details=detail,#"Refreshed UTC"=NowUTC],
    UncatSerials = Detail[Evidence Serial Number],
    GoldenSource = Excel.CurrentWorkbook(){[Name="tblExpectedReport"]}[Content],
    GoldenText = Table.TransformColumns(GoldenSource,List.Transform(List.RemoveItems(ReportHeaders,{"Days Past Due","Days Between Create and Upload Date"}),(h)=>{h,TextValue,type text})),
    Golden = Table.Sort(Table.TransformColumnTypes(GoldenText,{{"Days Past Due",Int64.Type},{"Days Between Create and Upload Date",Int64.Type}},"en-US"),{{"Days Past Due",Order.Descending},{"Evidence Serial Number",Order.Ascending}}),
    Checks = {
        Check("T01.1","Exact 70-column schema","70 fields, exact order",if MainRead[SchemaOK] then "70 fields, exact order" else MainRead[ErrorCode],MainRead[SchemaOK],MainRead[ErrorMessage],false),
        Check("T01.2","Baseline source row count",ExpectedRows,Table.RowCount(MainRead[Data]),Table.RowCount(MainRead[Data])=ExpectedRows,"Populated CSV records, not physical lines",true),
        Check("T01.3","Accepted / rejected rows","0 rejected",Table.RowCount(Main[Rejected]),Table.RowCount(Main[Rejected])=0,"All invalid rows retained on Rejected Rows",false),
        Check("T02","Empty CSV padding","40 empty; same 1000 records",try Table.SelectRows(TestResults,each [File]="padded_valid_input.csv"){0}[Status] otherwise "SKIPPED",Safe(()=>Table.SelectRows(TestResults,each [File]="padded_valid_input.csv"){0}[Status]="PASS" and Table.ToRows(ReadCsv("test-inputs/padded_valid_input.csv")[Data])=Table.ToRows(MainRead[Data])),"Padded input tested separately from primary input",true),
        Check("T03.1","Uncategorized total",ExpectedUncat,Table.RowCount(Detail),Table.RowCount(Detail)=ExpectedUncat,"Trim Categories; no status or evidence-type filter",true),
        Check("T03.2","Whitespace category included","M00012 included",List.Contains(UncatSerials,"M00012"),List.Contains(UncatSerials,"M00012"),"Three spaces normalize to an empty category",true),
        Check("T03.3","Populated multi-category excluded","M00011 excluded",not List.Contains(UncatSerials,"M00011"),not List.Contains(UncatSerials,"M00011"),"Comma-separated categories remain a single CSV field",true),
        Check("T04","CSV commas, quotes, embedded newline","Intact notes",Safe(()=>Text.Contains(RawAnchor("M00013")[Notes],"#(lf)") and Text.Contains(RawAnchor("M00013")[Notes],"""quoted text""")),Safe(()=>Text.Contains(RawAnchor("M00013")[Notes],"#(lf)") and Text.Contains(RawAnchor("M00013")[Notes],"""quoted text""")),"Csv.Document uses UTF-8 and QuoteStyle.Csv",true),
        Check("T06","UTC midnight conversion","M00007 age 2",try Anchor("M00007")[Days Past Due] otherwise -1,Safe(()=>Anchor("M00007")[Days Past Due]=2),"Local upload day differs from UTC day",true),
        Check("T07.1","45-day upload delay",45,try RawAnchor("M00008")[Days Between Create and Upload Date] otherwise "missing",Safe(()=>Number.FromText(RawAnchor("M00008")[Days Between Create and Upload Date])=45),"Elapsed duration is floored, not calendar dates",true),
        Check("T07.2","One-hour midnight upload delay",0,try RawAnchor("M00010")[Days Between Create and Upload Date] otherwise "missing",Safe(()=>Number.FromText(RawAnchor("M00010")[Days Between Create and Upload Date])=0),"Midnight does not add a full elapsed day",true),
        Check("T08.1","Zero and decimal numerics","Zero accepted / decimals retained",Safe(()=>ParseNumber(RawAnchor("M00028")[#"Size (MB)"])=0),Safe(()=>ParseNumber(RawAnchor("M00028")[#"Size (MB)"])=0 and List.AnyTrue(List.Transform(Main[Accepted][#"Size (MB)"],each Number.Mod(Number.FromText(_,"en-US"),1)<>0))),"Numeric parsing is explicit en-US",true),
        Check("T08.2","Apostrophe longitude","-97 numeric",try Number.FromText(Text.TrimStart(RawAnchor("M00028")[Longitude],{"'"}),"en-US") otherwise null,Safe(()=>Number.FromText(Text.TrimStart(RawAnchor("M00028")[Longitude],{"'"}),"en-US")=-97),"Prefix removed only for numeric parsing; raw text retained",true),
        Check("T08.3","Y flags, compact viewed timestamp, Unicode","All retained",Safe(()=>RawAnchor("M00029")[#"Restricted (Y/N)"]="Y"),Safe(()=>RawAnchor("M00029")[#"Restricted (Y/N)"]="Y" and Text.Length(RawAnchor("M00031")[Last Viewed On])=20 and Text.Contains(RawAnchor("M00034")[Owner First Name],"É")),"No blanket punctuation or identifier cleaning",true),
        Check("T09.1","Missing owner remains included","M00014 included",List.Contains(UncatSerials,"M00014"),Safe(()=>List.Contains(UncatSerials,"M00014") and RawAnchor("M00014")[Owner First Name]=""),"Missing owner is not an exclusion filter",true),
        Check("T09.2","Single target across multiple groups","HSI Boston",try Anchor("M00017")[Component Name] otherwise "missing",Safe(()=>Anchor("M00017")[Component Name]="HSI Boston"),"One row counted once",true),
        Check("T09.3","Blank / unknown / conflicting groups","Blank organizations",Safe(()=>List.AllTrue(List.Transform({"M00015","M00018","M00019"},each Anchor(_)[Component]=""))),Safe(()=>List.AllTrue(List.Transform({"M00015","M00018","M00019"},each Anchor(_)[Component]=""))),"No device-home fallback; review Mapping Exceptions",true),
        Check("T09.4","Crosswalk keys","Unique nonblank group keys",MapKeysValid,MapKeysValid,"Duplicate crosswalk keys cannot assign an organization",false),
        Check("T10","Optional device and end date","Records retained",Safe(()=>RawAnchor("M00016")[Device ID]="" and RawAnchor("M00032")[#"Date (Record End)"]=""),Safe(()=>RawAnchor("M00016")[Device ID]="" and RawAnchor("M00032")[#"Date (Record End)"]="" and List.Contains(UncatSerials,"M00016") and List.Contains(UncatSerials,"M00032")),"Optional metadata does not remove evidence",true),
        Check("T11.1","All six evidence types",6,List.Count(List.Distinct(Detail[Evidence Type])),List.Count(List.Distinct(Detail[Evidence Type]))=6,"Headings saying Videos still count all types",true),
        Check("T11.2","Both statuses retained",2,List.Count(List.Distinct(Detail[Status])),List.Contains(Detail[Status],"Active") and List.Contains(Detail[Status],"Queued for Deletion"),"No status inferred from Date Deleted",true),
        Check("T12","Active future deletion metadata","Active, future date",try RawAnchor("M00020")[Status] otherwise "missing",Safe(()=>RawAnchor("M00020")[Status]="Active" and Date.From(DateTimeZone.ToUtc(ParseStamp(RawAnchor("M00020")[Date Deleted])))>AsOf and List.Contains(UncatSerials,"M00020")),"A future Date Deleted is metadata, not proof of deletion",true),
        Check("T13.1","Duplicate Evidence ID","Second row rejected",try Table.SelectRows(TestResults,each [File]="duplicate_evidence_id.csv"){0}[Status] otherwise "SKIPPED",Safe(()=>Table.SelectRows(TestResults,each [File]="duplicate_evidence_id.csv"){0}[Status]="PASS"),"Keep first otherwise-valid occurrence",true),
        Check("T13.2","Duplicate evidence serial","Second row rejected",try Table.SelectRows(TestResults,each [File]="duplicate_evidence_serial.csv"){0}[Status] otherwise "SKIPPED",Safe(()=>Table.SelectRows(TestResults,each [File]="duplicate_evidence_serial.csv"){0}[Status]="PASS"),"Separate input; not appended to main source",true),
        Check("T14.1","Age bands reconcile",Table.RowCount(Detail),Table.RowCount(Critical)+Table.RowCount(Overdue)+Table.RowCount(Recent),Table.RowCount(Critical)+Table.RowCount(Overdue)+Table.RowCount(Recent)=Table.RowCount(Detail) and List.AllTrue(List.Transform(Detail[Days Past Due],each _>=0)),"No overlaps; day 30 belongs to 15-30",false),
        Check("T14.2","LEO summary reconciles",Table.RowCount(Detail),List.Sum(Owners[Total Uncategorized Items]),List.Sum(Owners[Total Uncategorized Items])=Table.RowCount(Detail),"Retains blank owner/group keys",false),
        Check("T14.3","Golden report: every cell","Exact saved fixture projection",Safe(()=>Table.ToRows(Detail)=Table.ToRows(Golden)),Safe(()=>Table.ToRows(Detail)=Table.ToRows(Golden)),"Independent expected report retained on hidden Expected Report sheet",true),
        Check("T15","Malformed input suite","Four expected failures detected",try Table.RowCount(Table.SelectRows(TestResults,each List.Contains({"invalid_timestamp.csv","invalid_numeric.csv","missing_evidence_id.csv","missing_required_header.csv"},[File]) and [Status]="PASS")) otherwise 0,Safe(()=>Table.RowCount(Table.SelectRows(TestResults,each List.Contains({"invalid_timestamp.csv","invalid_numeric.csv","missing_evidence_id.csv","missing_required_header.csv"},[File]) and [Status]="PASS"))=4),"Record errors quarantined; missing required header rejects the file",true),
        Check("T16","Stable source re-read / golden output","Identical parsed records",Safe(()=>Table.ToRows(ReadCsv(SourceFile)[Data])=Table.ToRows(MainRead[Data])),Safe(()=>Table.ToRows(ReadCsv(SourceFile)[Data])=Table.ToRows(MainRead[Data]) and Table.ToRows(Detail)=Table.ToRows(Golden)),"Generator seed reproducibility is documented in the original test pack; this check covers PQ reads and transformations",true)
    },
    BoundaryChecks = List.Transform({{0,"M00001"},{14,"M00002"},{15,"M00003"},{29,"M00004"},{30,"M00005"},{31,"M00006"}},(pair)=>Check("T05."&Text.From(pair{0}),"Exact age "&Text.From(pair{0}),pair{0},try Anchor(pair{1})[Days Past Due] otherwise -1,Safe(()=>Anchor(pair{1})[Days Past Due]=pair{0}),"Critical >30; overdue 15-30 inclusive; recent <15",true)),
    Validation = Table.FromRecords(Checks&BoundaryChecks),
    Audit = #table(type table [Metric=text,Value=text,#"Refreshed UTC"=text],{
        {"Source file",Path(SourceFile),NowUTC},{"Schema valid",Text.From(MainRead[SchemaOK]),NowUTC},{"File error",MainRead[ErrorCode]&" "&MainRead[ErrorMessage],NowUTC},
        {"As-of UTC date",Date.ToText(AsOf,"yyyy-MM-dd"),NowUTC},{"Populated source records",Text.From(Table.RowCount(MainRead[Data])),NowUTC},{"Ignored blank records",Text.From(MainRead[BlankRows]),NowUTC},
        {"Accepted records",Text.From(Table.RowCount(Main[Accepted])),NowUTC},{"Rejected records",Text.From(Table.RowCount(Main[Rejected])),NowUTC},{"Uncategorized records",Text.From(Table.RowCount(Detail)),NowUTC},
        {"Categorized accepted records",Text.From(Table.RowCount(Main[Accepted])-Table.RowCount(Detail)),NowUTC},{"Critical >30",Text.From(Table.RowCount(Critical)),NowUTC},{"Overdue 15-30",Text.From(Table.RowCount(Overdue)),NowUTC},{"Recent <15",Text.From(Table.RowCount(Recent)),NowUTC},
        {"Mapping exceptions (all accepted)",Text.From(Table.RowCount(Exceptions)),NowUTC},{"Fixture checks enabled",Text.From(FixtureChecks),NowUTC}
    })
in
    [Tables=Tables,Validation=Validation,Audit=Audit,Rejected=Main[Rejected],MappingExceptions=Exceptions,TestInputs=TestResults]

