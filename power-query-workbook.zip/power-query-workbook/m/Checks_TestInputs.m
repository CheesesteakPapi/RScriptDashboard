EvidenceModel[TestInputs]
