EvidenceModel[Tables][CriticalComponents]
