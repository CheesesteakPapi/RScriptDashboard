# Use the existing published Dataverse token

Prepared November 2, 2026. This is a local integration specification; it has not changed a flow, Dataverse table, GitHub repository, or live connection.

## Current template binding

The user has supplied the environment `https://icewbc-dev.crm9.dynamics.com`, table `bwc_axonauthcache`, entity set `bwc_axonauthcaches`, token property `AccessToken`, expiry property `ExpiresAtUtc`, and Bearer scheme, and confirmed one current Axon token row. The selected template therefore uses List rows with row count 2 and requires exactly one result; a row GUID/filter is not needed under this contract.

Use **Dataverse Token Reader - Template.md** and the two `*.template.json` files as the configured template. Connection references and field names remain editable, and live metadata/authentication is unverified. The detailed notes below retain the general alternatives; they do not require additional input to prepare the template.

## Confirmed direction

The user already operates a token-refresh process that publishes the updated token in Dataverse. That existing process remains the token publisher. The reporting process consumes its published token; it does not require another client-secret entry or a second OAuth token-request action.

The [shared project conversation](https://chatgpt.com/s/cx_6ae87b2772408191837bc9b1befa7480) selects the recurring cloud architecture:

```text
Existing token-refresh process
          |
          v
Dataverse published-token row
          |
          v
Power Automate acquisition -> Axon report API
          |
          v
Excel Online processing -> SharePoint completed output -> Power BI Service
```

The token lookup belongs to the Power Automate acquisition flow. The report workbook and Power BI queries continue to consume the published report data. The local CSV workbook is a transformation-test artifact and does not need live API credentials.

The current repository guides still describe a new `Get_Axon_Token` POST and a client-secret source. For this user's implementation, replace those authentication instructions with the published-token lookup described below. The repository was read for context; it was not edited or pushed.

## Bindings still required

Supply schema information rather than token values:

| Binding | Purpose |
|---|---|
| Dataverse environment URL | Select the intended environment/connection. |
| Table logical name | Identify the published-token table. For Web API use, also verify its actual entity-set name; do not derive it by guessing a plural. |
| Row GUID or exact identifying filter | Select the intended agency/client/environment token. Confirm whether the publisher updates one stable row or appends history. |
| Access-token column logical name | Retrieve the published access token. Confirm whether the value is a raw token or already contains an authorization scheme. |
| Expiry column logical name, if present | Check the actual expiry value and format; do not infer a fixed lifetime. |
| Publication/version metadata, if present | Diagnose stale publication without recording the token itself. |

The Dataverse connection identity must already have the intended table/column read access. This specification does not create or broaden that access.

## Flow changes

1. **Read the published row before the first Axon report request.** If the publisher maintains a stable row GUID, use Microsoft Dataverse **Get a row by ID**, named `Get_Published_Axon_Token`. If only a selector is available, use **List rows**, selecting only the token, expiry, identifier, and necessary publication metadata columns. Use the exact selector. For a single-current-row contract, request up to two matches and require exactly one. An appended token-history table needs an explicit current-row selection contract; do not silently select an arbitrary first row.
2. **Validate the retrieved value.** Require a nonempty token. If expiry is published, validate its timestamp format and ensure it is sufficiently beyond the current UTC time for the next request. The freshness margin is an integration setting, initially proposed as two minutes; it must agree with the existing publisher's schedule and token lifetime. Missing, malformed, expired, or ambiguous publication fails acquisition while retaining the previous completed report.
3. **Reference the secure lookup output directly in the report request.** For a raw-token column and the Get-row action above, use this Authorization expression, replacing the column placeholder with the observed logical name:

   ```text
   concat('Bearer ', trim(body('Get_Published_Axon_Token')?['<ACCESS_TOKEN_COLUMN>']))
   ```

   This is an expression template, not a ready-to-run binding. If the field already includes `Bearer`, use its validated value directly instead of adding a second prefix. The Dataverse connection authenticates the lookup; the published Axon token authenticates the Axon API request.

4. **Reuse the token for subsequent pages while it remains valid.** Preserve the project's complete Created/Updated pagination and error handling. Check published expiry as needed for a long acquisition. The acquisition flow reads the publisher's output rather than initiating an independent renewal process.
5. **On the first report-request 401 for a page, re-read the published row once.** If it contains a newer, valid token, retry the same page once. If publication has not produced a usable replacement, or a second 401 occurs, fail the run. Do not advance the page index or publication watermark. A 403 remains an authorization/permission failure; it is not evidence that token renewal will help.
6. **Keep publication atomic with successful processing.** Continue processing a working copy and update SharePoint `latest` only after complete acquisition, successful processing, and the existing quality checks. An authentication failure preserves the prior successful report and its watermark.

## Token handling

Use the supported secure input/output settings on the Dataverse token-read action and downstream actions carrying the Authorization header. Avoid intermediary Compose or variable outputs that would expose the token in run history. Confirm action masking with dummy data before a live run.

Do not load the token table into worksheet output, the Power BI model, report files, validation tables, source-control files, or diagnostic logs. Diagnostic output can contain retrieval status, nonsecret row/version identifiers, expiry/freshness status, and HTTP status codes.

## Validation cases for the authentication integration

| Case | Expected behavior |
|---|---|
| Exactly one matching row with usable token and future expiry | Axon request can proceed using the published value. |
| No matching row | Acquisition fails with a configuration/publication error; retain latest. |
| Multiple matches under a single-current-row contract | Fail as ambiguous; do not pick an arbitrary row. |
| Empty token | Fail before sending an Axon request. |
| Malformed or expired expiry | Fail freshness validation; no invented lifetime. |
| Expiry column absent by design | Record that expiry cannot be checked; use the agreed publisher contract and bounded 401 handling. |
| Dataverse read permission or service failure | Fail acquisition; do not treat it as an empty token table. |
| First report 401; published token has changed and is usable | Retry the same page once. |
| First report 401; no usable replacement, or second 401 | Fail acquisition without advancing page or watermark. |
| Report 403 | Fail permission validation; do not loop token reads. |
| Token rotates during a long paginated run | Re-read as required by the agreed freshness rule; preserve page position. |
| Token-bearing action inspected in run history | Values remain masked; report outputs contain no token. |

These are test designs. No Dataverse row was read and no live Axon request or flow execution was performed in preparing this specification.

## Rule alignment from the linked project

The linked project specifies critical at **30+ days** and moderate at **15–29 days**. The earlier local mock pair used **greater than 30** and **15–30 inclusive** as an explicit fixture choice. Preserve that earlier pair as a historical fixture; align configurable cutoffs and expected boundary results before comparing it against the cloud project. Token integration does not itself alter the archived CSV/report.

## Sources

- [Shared project context](https://chatgpt.com/s/cx_6ae87b2772408191837bc9b1befa7480).
- [Current repository implementation guide](https://github.com/CheesesteakPapi/RScriptDashboard/blob/main/docs/implementation-guide.md), read November 2, 2026; authentication guidance still describes direct token acquisition.
- [Current cloud setup guide](https://github.com/CheesesteakPapi/RScriptDashboard/blob/main/docs/microsoft-365-setup.md), read November 2, 2026.
- [Microsoft: List rows in Power Automate](https://learn.microsoft.com/en-us/power-automate/dataverse/list-rows), including selected columns, row filters, and row count.
- [Microsoft Dataverse connector reference](https://learn.microsoft.com/en-us/connectors/commondataservice/), including Get a row by ID and List rows.
