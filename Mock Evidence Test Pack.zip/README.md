# Mock evidence data test pack

Use `reports.evidenceCreated_mock.csv` as the test source and `Uncategorized Report Mock Data.xlsx` as its matching expected report. All identities, evidence IDs, device IDs, serial numbers, case numbers, and record metadata were invented. Titles and tags identify the records as mock data. Checksums are synthetic format tokens; no corresponding media exists.

The CSV keeps the supplied **70 headers in their exact order**. The report keeps the supplied **16 sheet names, sheet order, and data headers**. Its Instructions sheet documents the mock rules. The original attachments were not modified or included in this pack.

## Expected results

| Measure | Expected value |
|---|---:|
| Source records, excluding header | 1,000 |
| Categorized records excluded from the report | 243 |
| Uncategorized detail records | 757 |
| Critical: greater than 30 days | 302 |
| Overdue: 15–30 days inclusive | 205 |
| Recent: less than 15 days, including zero | 250 |
| Uncategorized Active records | 726 |
| Uncategorized Queued for Deletion records | 31 |
| Scenario groups | 16 |

The main CSV has unique Evidence IDs and evidence serials, valid timestamps, and no trailing padding. Report ID cells are intentionally blank, as in the supplied report. There are no extra test columns in the main CSV or extra worksheets in the report.

## Mock rules used to make the pair match

These are explicit fixture choices, not approved production policy:

1. **Fixed report date:** April 27, 2026. This matches the example's reference date and keeps boundary tests repeatable. The date is not today's date.
2. **Uncategorized:** trim `Categories` and include the record if the result is empty. A whitespace-only category is therefore uncategorized. Populated multi-category values are excluded.
3. **Age:** subtract the UTC calendar date of `Date Uploaded` from the fixed report date. No grace period is subtracted. Raw timestamps retain the applicable New York offset, including daylight saving changes. Report dates use UTC `YYYY-MM-DD` strings.
4. **Thresholds:** day 30 belongs to the 15–30 band; critical starts at day 31. Both >30 sheets use the same rule. This intentionally resolves the inconsistent day-30 behavior found in the supplied report.
5. **Upload delay:** use the floor of elapsed timestamp duration in 24-hour days. A one-hour upload crossing midnight has zero elapsed days.
6. **Status and type:** retain both Active and Queued for Deletion and all six evidence types. A populated `Date Deleted` never changes status. Original summary headers that say “Videos” are retained for format compatibility, but totals count all evidence types.
7. **Organization:** use only `mock-organization-crosswalk.csv`. Split comma-separated Owner Groups and trim each group. If all groups resolve to one organization, assign it once. Blank groups, any unmapped group, or conflicting organizations leave Component, Component Name, and AOR blank. Device home is not a fallback.
8. **Blank rollups:** AOR and Component Name overall totals exclude blank keys; the age-band AOR summaries include blanks. The >30 Component summary excludes blanks. LEO totals retain blank identity/group values and count every included record once.
9. **Original component views:** the supplied tab set has no dedicated view for component `Off`. Those synthetic records remain in the main detail and relevant summaries; do not sum only the named component detail tabs to obtain the whole report count.
10. **Duplicate test policy:** the main input is unique. In the separate duplicate test files, accept the first valid record and reject the later record with the repeated ID or serial. This is a fixture rule, not an inference about the production report.

The report is a static export, like the supplied example. Editing the CSV does not refresh the workbook; regenerate it after changing the source or rules.

## Test scenarios and traceability

`test-scenarios.csv` covers all 16 previously identified scenario groups. It identifies the relevant file and anchor evidence serials. `record-expectations.csv` gives one row per primary source record with inclusion, age band, mock organization mapping result, and scenario tags. CSV Record numbers start at 1 after the header; embedded newlines in notes mean physical line numbers differ.

Coverage includes exact schema, blank CSV records, blank/whitespace/multiple categories, quoted commas and multiline notes, ages 0/14/15/29/30/31, UTC midnight conversion, delayed uploads, decimal and zero values, apostrophe-prefixed longitude, compact viewed timestamps, Y/N flags, Unicode names, missing owner/device values, multiple and unknown groups, all evidence types, both statuses, future deletion metadata, duplicates, invalid inputs, rollups, and repeatable generation.

## Separate test inputs

Run these as individual inputs. They are not additional records to append to the primary source, and their rejected records do not appear in the primary expected report. The companion `test-inputs/expectations.json` records expected accept/reject counts, error codes, and record indexes.

| File | Expected result |
|---|---|
| `padded_valid_input.csv` | Same 1,000 populated records plus 40 all-empty records; use the primary report as the expected result. |
| `invalid_timestamp.csv` | Two records: accept the first; reject the second as `INVALID_DATE_UPLOADED`. |
| `invalid_numeric.csv` | Two records: accept the first; reject the second as `INVALID_SIZE_MB`. |
| `missing_evidence_id.csv` | Two records: accept the first; reject the second as `MISSING_EVIDENCE_ID`. |
| `duplicate_evidence_id.csv` | Two records: accept the first; reject the second as `DUPLICATE_EVIDENCE_ID`. |
| `duplicate_evidence_serial.csv` | Two records: accept the first; reject the second as `DUPLICATE_EVIDENCE_SERIAL`. |
| `missing_required_header.csv` | Reject the file as `SCHEMA_MISMATCH` before row processing; Categories is absent. |

The verifier's error codes describe this fixture's expected outcomes. Translate them to the consuming application's equivalent errors where necessary.

## Regenerate and verify

Requires Python 3.10+ with `openpyxl` (the included requirements file records the version used). From this folder:

```sh
python3 generate_mock_data.py
python3 verify_mock_data.py
```

For a different volume, preserve this baseline and generate into another folder:

```sh
python3 generate_mock_data.py --rows 10000 --seed 20261022 --as-of 2026-04-27 --out-dir ./larger-run
python3 verify_mock_data.py --directory ./larger-run
```

Supported volumes are 40 through 99,999 rows so every scenario anchor remains present and evidence serials keep six characters. Defaults are 1,000 rows, seed 20261022, and as-of 2026-04-27. The generator does not need the original attachments; `schema.json` contains their headers and source-file hashes. Smaller or larger runs have different totals; the table above documents only the supplied 1,000-record baseline.

## Verification performed

`validation.json` records successful local checks of the exact headers, every saved report detail cell against the CSV projection, every report summary, scenario anchors, and all seven separate inputs. It also checks that all main records are parseable and unique and that report inclusion counts reconcile. `reproducibility.json` records a second generation using the same settings: identical main CSV bytes and identical report cell values. Workbook container timestamps can differ between runs.

`SHA256SUMS.txt` covers the packaged files, excluding itself. To check the downloaded/extracted pack on macOS:

```sh
shasum -a 256 -c SHA256SUMS.txt
```

Verification covered saved files and the included fixture rules. No Power Query, production report code, or live data connector was run.
