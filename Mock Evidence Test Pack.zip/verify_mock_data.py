"""Read saved fixtures and independently reconcile every report row and aggregate."""
import argparse
from collections import Counter
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from uuid import UUID
import csv
import hashlib
import json

from openpyxl import load_workbook

UTC = timezone.utc


def read_csv(path):
    with path.open(newline='', encoding='utf-8-sig') as handle:
        records = list(csv.reader(handle))
    return records[0], records[1:]


def inspect_input(path, headers):
    actual, records = read_csv(path)
    populated = [row for row in records if any(value.strip() for value in row)]
    result = {'file': path.name, 'populated_records': len(populated), 'empty_records': len(records) - len(populated), 'accepted_records': 0, 'rejected_records': 0, 'error': None, 'rejected_csv_records': [], 'errors': []}
    if actual != headers:
        result.update({'error': 'SCHEMA_MISMATCH', 'file_rejected': True})
        return [], result
    accepted, seen_ids, seen_serials = [], set(), set()
    for index, values in enumerate(records, 1):
        if not any(value.strip() for value in values):
            continue
        codes = []
        if len(values) != len(headers):
            codes.append('FIELD_COUNT_MISMATCH')
        row = dict(zip(headers, values))
        if codes:
            pass
        else:
            if not row['Evidence ID'].strip():
                codes.append('MISSING_EVIDENCE_ID')
            else:
                try:
                    UUID(row['Evidence ID'])
                except ValueError:
                    codes.append('INVALID_EVIDENCE_ID')
            if not row['Evidence Serial Number'].strip():
                codes.append('MISSING_EVIDENCE_SERIAL')
            if row['Evidence ID'] in seen_ids:
                codes.append('DUPLICATE_EVIDENCE_ID')
            if row['Evidence Serial Number'] in seen_serials:
                codes.append('DUPLICATE_EVIDENCE_SERIAL')
            for field, code in [('Date Uploaded', 'INVALID_DATE_UPLOADED'), ('Created Date (Record Start)', 'INVALID_RECORD_START'), ('Date Modified', 'INVALID_DATE_MODIFIED')]:
                try:
                    value = datetime.fromisoformat(row[field])
                    if value.utcoffset() is None:
                        codes.append(code)
                except ValueError:
                    codes.append(code)
            for field, code in [('Size (MB)', 'INVALID_SIZE_MB'), ('Duration (seconds)', 'INVALID_DURATION'), ('View Count', 'INVALID_VIEW_COUNT'), ('Download Count', 'INVALID_DOWNLOAD_COUNT'), ('Authenticated Share Count', 'INVALID_SHARE_COUNT'), ('Days Between Create and Upload Date', 'INVALID_UPLOAD_DELAY')]:
                try:
                    number = Decimal(row[field])
                    if not number.is_finite() or number < 0:
                        codes.append(code)
                except InvalidOperation:
                    codes.append(code)
        if codes:
            result['rejected_csv_records'].append(index)
            result['errors'].append({'csv_record': index, 'codes': codes})
        else:
            accepted.append(row)
            seen_ids.add(row['Evidence ID'])
            seen_serials.add(row['Evidence Serial Number'])
    result['accepted_records'] = len(accepted)
    result['rejected_records'] = len(result['rejected_csv_records'])
    error_set = {code for entry in result['errors'] for code in entry['codes']}
    result['error'] = next(iter(error_set)) if len(error_set) == 1 else sorted(error_set) if error_set else None
    return accepted, result


def normalize(value):
    return '' if value is None else value


def verify(root):
    schema = json.loads((root / 'schema.json').read_text())
    config = json.loads((root / 'fixture-config.json').read_text())
    as_of = date.fromisoformat(config['as_of'])
    rows, main_check = inspect_input(root / 'reports.evidenceCreated_mock.csv', schema['csv_headers'])
    assert main_check['error'] is None and main_check['rejected_records'] == 0
    assert len(rows) == config['rows'] and main_check['empty_records'] == 0
    assert len({r['Evidence ID'] for r in rows}) == len(rows)
    assert len({r['Evidence Serial Number'] for r in rows}) == len(rows)
    assert all(r['Title'].startswith('MOCK ') and 'SYNTHETIC' in r['Tags'] for r in rows)
    cw_headers, cw_rows = read_csv(root / 'mock-organization-crosswalk.csv')
    crosswalk = {r[0]: tuple(r[1:]) for r in cw_rows}
    assert cw_headers == ['Owner Group', 'Component', 'Component Name', 'AOR']
    assert len(crosswalk) == len(cw_rows)
    details, mapped = [], {}
    for r in rows:
        start = datetime.fromisoformat(r['Created Date (Record Start)'])
        upload = datetime.fromisoformat(r['Date Uploaded'])
        assert upload >= start
        assert int((upload - start).total_seconds() // 86400) == int(r['Days Between Create and Upload Date'])
        assert r['Flag (Y/N)'] in {'Y', 'N'} and r['Restricted (Y/N)'] in {'Y', 'N'} and r['Reassigned (Y/N)'] in {'Y', 'N'}
        assert Decimal('-90') <= Decimal(r['Latitude']) <= Decimal('90')
        assert Decimal('-180') <= Decimal(r['Longitude'].removeprefix("'")) <= Decimal('180')
        if r['Last Viewed On']:
            datetime.strptime(r['Last Viewed On'], '%Y%m%dT%H%M%S%z')
        for field in ['Date (Record End)', 'Date Deleted']:
            if r[field]:
                dt = datetime.fromisoformat(r[field])
                assert dt.utcoffset() is not None
                if field == 'Date (Record End)':
                    assert abs((dt - start).total_seconds() - float(r['Duration (seconds)'])) < 0.002
        groups = [g.strip() for g in r['Owner Groups'].split(',') if g.strip()]
        mapped_groups = [crosswalk[g] for g in groups if g in crosswalk]
        org = mapped_groups[0] if groups and len(mapped_groups) == len(groups) and len(set(mapped_groups)) == 1 else ('', '', '')
        age = (as_of - upload.astimezone(UTC).date()).days
        assert age >= 0
        d = dict(r)
        d.update({'Days Past Due': age, 'ID': '', 'Created Date (Record Start)': start.astimezone(UTC).date().isoformat(), 'Date Uploaded': upload.astimezone(UTC).date().isoformat(), 'Days Between Create and Upload Date': int(r['Days Between Create and Upload Date']), 'Component': org[0], 'Component Name': org[1], 'AOR': org[2]})
        mapped[r['Evidence Serial Number']] = d
        if not r['Categories'].strip():
            details.append(d)
    details.sort(key=lambda r: (-r['Days Past Due'], r['Evidence Serial Number']))
    book = load_workbook(root / 'Uncategorized Report Mock Data.xlsx', data_only=False, read_only=True)
    assert book.sheetnames == schema['sheet_order']
    saved = {ws.title: [[normalize(c.value) for c in row] for row in ws] for ws in book}
    assert not any(c.data_type in {'f', 'e'} for ws in book for row in ws for c in row)
    tab_checks = {}
    component_tabs = {'HSI Uncat #s': 'HSI', 'ERO Uncat #s': 'ERO', 'FLETC Uncat #s': 'FLETC', 'FOIA Uncat #s': 'FOIA', 'OPR Uncat #s': 'Office of Professional Responsibility', 'OFTP Uncat #s': 'Office of Firearms and Tactical Programs', 'Blanks Uncat #s': ''}
    for title, headers in schema['sheet_headers'].items():
        assert saved[title][0] == headers, f'Header mismatch: {title}'
        actual = saved[title][1:]
        if title == 'Days Past Due' or title in component_tabs:
            selected = details if title == 'Days Past Due' else [r for r in details if r['Component'] == component_tabs[title]]
            assert actual == [[r[h] for h in headers] for r in selected], f'Detail mismatch: {title}'
            tab_checks[title] = {'rows': len(actual), 'all_cells_match_source_projection': True}
        elif title == 'LEO Uncat #s':
            expected = Counter(tuple(r[h] for h in headers[1:]) for r in details)
            actual_counts = {tuple(r[1:]): r[0] for r in actual}
            assert len(actual_counts) == len(actual) and actual_counts == expected
            assert sum(actual_counts.values()) == len(details)
            tab_checks[title] = {'groups': len(actual), 'count_total': sum(actual_counts.values()), 'reconciled': True}
        else:
            field = headers[0]
            if title in ['> 30 Days Component Uncat #s', '> 30 Days Uncat #s']:
                selected = [r for r in details if r['Days Past Due'] >= 31]
            elif title == '15 - 30 Days Uncat #s':
                selected = [r for r in details if r['Days Past Due'] in range(15, 31)]
            elif title == '< 15 Days Uncat #s':
                selected = [r for r in details if r['Days Past Due'] in range(0, 15)]
            else:
                selected = details
            include_blank = title in ['> 30 Days Uncat #s', '15 - 30 Days Uncat #s', '< 15 Days Uncat #s']
            expected = Counter(r[field] for r in selected if include_blank or r[field])
            actual_counts = {r[0]: r[1] for r in actual}
            assert len(actual_counts) == len(actual) and actual_counts == expected, f'Rollup mismatch: {title}'
            tab_checks[title] = {'groups': len(actual), 'count_total': sum(actual_counts.values()), 'reconciled': True}
    assert sum(tab_checks[t]['count_total'] for t in ['> 30 Days Uncat #s', '15 - 30 Days Uncat #s', '< 15 Days Uncat #s']) == len(details)
    raw_by = {r['Evidence Serial Number']: r for r in rows}
    detail_by = {r['Evidence Serial Number']: r for r in details}
    anchors = config['anchors']
    for age in [0, 14, 15, 29, 30, 31]:
        assert detail_by[anchors[f'T05-DAY-{age}']]['Days Past Due'] == age
    assert detail_by[anchors['T06-UTC-MIDNIGHT']]['Days Past Due'] == 2
    assert detail_by[anchors['T03-WHITESPACE-CATEGORY']]['Evidence Serial Number']
    assert anchors['T03-CATEGORIZED-T04-MULTI-CATEGORY'] not in detail_by
    assert '"' in raw_by[anchors['T04-QUOTES-NEWLINE']]['Notes'] and '\n' in raw_by[anchors['T04-QUOTES-NEWLINE']]['Notes']
    for key in ['T09-BLANK-GROUP-HOME-PRESENT', 'T09-MULTI-GROUP-CONFLICT', 'T09-UNMAPPED-GROUP']:
        assert detail_by[anchors[key]]['Component'] == ''
    assert detail_by[anchors['T09-MULTI-GROUP-SAME-ORG']]['Component Name'] == 'HSI Boston'
    assert raw_by[anchors['T09-MISSING-OWNER']]['Owner First Name'] == ''
    assert raw_by[anchors['T10-MISSING-DEVICE']]['Device ID'] == ''
    assert raw_by[anchors['T10-OPTIONAL-END-DATE']]['Date (Record End)'] == ''
    future = raw_by[anchors['T12-ACTIVE-FUTURE-DELETE']]
    assert future['Status'] == 'Active' and datetime.fromisoformat(future['Date Deleted']).date() > as_of
    assert int(raw_by[anchors['T07-DELAYED-UPLOAD']]['Days Between Create and Upload Date']) == 45
    for key in ['T07-SAME-DAY', 'T07-CROSS-MIDNIGHT']:
        assert raw_by[anchors[key]]['Days Between Create and Upload Date'] == '0'
    assert {r['Evidence Type'] for r in details} == {'Video', 'Audio', 'Image', 'Document', 'Other', 'Firing Log'}
    assert {r['Status'] for r in details} == {'Active', 'Queued for Deletion'}
    exp_headers, exp_rows = read_csv(root / 'record-expectations.csv')
    assert len(exp_rows) == len(rows)
    for expected in [dict(zip(exp_headers, r)) for r in exp_rows]:
        d = mapped[expected['Evidence Serial Number']]
        assert expected['Evidence ID'] == d['Evidence ID']
        assert expected['Included'] == ('Y' if not d['Categories'].strip() else 'N')
        assert int(expected['Days Past Due']) == d['Days Past Due']
        for h in ['Component', 'Component Name', 'AOR']:
            assert expected[h] == d[h]
    variant_results = []
    for expected in json.loads((root / 'test-inputs' / 'expectations.json').read_text()):
        accepted, actual = inspect_input(root / 'test-inputs' / expected['file'], schema['csv_headers'])
        for key, value in expected.items():
            assert actual.get(key) == value, (expected['file'], key, actual.get(key), value)
        if expected['file'] == 'padded_valid_input.csv':
            assert accepted == rows
        variant_results.append(actual)
    test_headers, test_rows = read_csv(root / 'test-scenarios.csv')
    assert {r[0] for r in test_rows} == {f'T{n:02d}' for n in range(1, 17)}
    cells_digest = hashlib.sha256(json.dumps(saved, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
    book.close()
    summary = {'status': 'passed', 'raw_records': len(rows), 'raw_columns': len(schema['csv_headers']), 'categorized_records': len(rows) - len(details), 'uncategorized_records': len(details), 'report_worksheet_count': len(saved), 'age_bands': {'>30': sum(r['Days Past Due'] > 30 for r in details), '15-30': sum(15 <= r['Days Past Due'] <= 30 for r in details), '<15': sum(r['Days Past Due'] < 15 for r in details)}, 'evidence_types': dict(Counter(r['Evidence Type'] for r in details)), 'statuses': dict(Counter(r['Status'] for r in details)), 'main_csv_sha256': hashlib.sha256((root / 'reports.evidenceCreated_mock.csv').read_bytes()).hexdigest(), 'report_cell_values_sha256': cells_digest, 'scenario_count': len(test_rows), 'tab_checks': tab_checks, 'test_input_results': variant_results, 'verification_boundary': 'Saved file/schema, per-record values, all report rollups, scenario anchors, and test-input rejection outcomes verified locally; no live connector refresh performed.'}
    (root / 'validation.json').write_text(json.dumps(summary, indent=2) + '\n')
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--directory', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    result = verify(args.directory.resolve())
    print(json.dumps({k: v for k, v in result.items() if k not in ['tab_checks', 'test_input_results']}, indent=2))
