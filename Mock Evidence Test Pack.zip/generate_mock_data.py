"""Generate standalone synthetic fixtures; no connection or source record access required."""
import argparse
from collections import Counter
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path
from uuid import UUID, uuid5
from zoneinfo import ZoneInfo
import csv
import hashlib
import json
import random
import shutil

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

HERE = Path(__file__).resolve().parent
UTC = timezone.utc
NY = ZoneInfo('America/New_York')
NAMESPACE = UUID('52f91cf9-8052-4a44-b6bc-18ae9d4f98e0')
ORG_ROWS = [
    ('HSI Boston Users', 'HSI', 'HSI Boston', 'AOR Boston'),
    ('HSI Boston Reviewers', 'HSI', 'HSI Boston', 'AOR Boston'),
    ('HSI Washington Users', 'HSI', 'HSI Washington', 'AOR Washington'),
    ('ERO Buffalo Users', 'ERO', 'ERO Buffalo', 'AOR Buffalo'),
    ('ERO Washington Users', 'ERO', 'ERO Washington', 'AOR Washington'),
    ('FLETC Charleston', 'FLETC', 'FLETC Charleston', 'FLETC Charleston'),
    ('FOIA', 'FOIA', 'FOIA', 'FOIA'),
    ('Office of Professional Responsibility', 'Office of Professional Responsibility', 'Office of Professional Responsibility', 'Office of Professional Responsibility'),
    ('Office of Firearms and Tactical Programs', 'Office of Firearms and Tactical Programs', 'Office of Firearms and Tactical Programs', 'Office of Firearms and Tactical Programs'),
    ('Mock Auxiliary Users', 'Off', 'Mock Auxiliary Office', 'Mock Auxiliary Office'),
]
CONTENT = {'Video': 'mp4', 'Audio': 'm4a', 'Image': 'jpg', 'Document': 'pdf', 'Other': 'dat', 'Firing Log': 'log'}
ROLES = ['Agent', 'Lite User', 'Coordinator', 'Redactor', 'Taser Instructor', 'Lite Armorer', 'PMO']


def write_csv(path, fields, rows, padding=0):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator='\r\n')
        writer.writeheader()
        writer.writerows(rows)
        for _ in range(padding):
            writer.writerow(dict.fromkeys(fields, ''))


def fmt(value):
    return value.astimezone(NY).isoformat(timespec='milliseconds')


def uid(seed, label):
    return str(uuid5(NAMESPACE, f'MOCK:{seed}:{label}')).upper()


def resolve_org(groups):
    lookup = {r[0]: r[1:] for r in ORG_ROWS}
    tokens = [g.strip() for g in groups.split(',') if g.strip()]
    if not tokens:
        return ('', '', ''), 'blank groups'
    if any(g not in lookup for g in tokens):
        return ('', '', ''), 'unmapped group'
    targets = {lookup[g] for g in tokens}
    if len(targets) != 1:
        return ('', '', ''), 'conflicting organizations'
    return targets.pop(), 'mapped'


def make_records(schema, count, seed, as_of):
    rng = random.Random(seed)
    rows, anchors = [], {}
    ages = [0, 1, 2, 7, 14, 15, 16, 29, 30, 31, 45, 90, 180, 365, 740]
    base_groups = [r[0] for r in ORG_ROWS if r[0] != 'HSI Boston Reviewers'] + ['']
    for n in range(1, count + 1):
        row = dict.fromkeys(schema['csv_headers'], '')
        age = rng.choice(ages)
        upload = datetime.combine(as_of - timedelta(days=age), time(16, 0), UTC) + timedelta(minutes=rng.randrange(180))
        delay = timedelta(days=rng.choice([0, 0, 0, 1, 3, 14, 45]), hours=2)
        kind = rng.choice(list(CONTENT))
        owner = 1 + (n - 1) % 80
        group = base_groups[(n - 1) % len(base_groups)]
        categories = 'Training/Testing' if n % 4 == 0 else ''
        if n % 40 == 0:
            categories = 'Training/Testing,Mock Review'
        status = 'Queued for Deletion' if n % 25 == 0 else 'Active'
        tags = ['MOCK', 'SYNTHETIC']

        def case(name):
            tags.append(name)
            anchors[name] = f'M{n:05d}'

        if n <= 6:
            age = [0, 14, 15, 29, 30, 31][n - 1]
            upload = datetime.combine(as_of - timedelta(days=age), time(16, 0), UTC)
            categories, group, kind = '', 'HSI Washington Users', 'Video'
            case(f'T05-DAY-{age}')
        if n == 7:
            upload = datetime.combine(as_of - timedelta(days=3), time(23, 30), NY).astimezone(UTC)
            delay, categories = timedelta(minutes=30), ''
            case('T06-UTC-MIDNIGHT')
        if n == 8:
            delay, categories = timedelta(days=45, hours=2), ''
            case('T07-DELAYED-UPLOAD')
        if n == 9:
            delay, categories = timedelta(hours=2), ''
            case('T07-SAME-DAY')
        if n == 10:
            upload = datetime.combine(as_of - timedelta(days=2), time(0, 30), NY).astimezone(UTC)
            delay, categories = timedelta(hours=1), ''
            case('T07-CROSS-MIDNIGHT')
        if n == 11:
            categories = 'Training/Testing,Mock Review'
            case('T03-CATEGORIZED-T04-MULTI-CATEGORY')
        if n == 12:
            categories = '   '
            case('T03-WHITESPACE-CATEGORY')
        if n == 13:
            categories = ''
            case('T04-QUOTES-NEWLINE')
        if n == 14:
            categories = ''
            case('T09-MISSING-OWNER')
        if n == 15:
            group, categories = '', ''
            case('T09-BLANK-GROUP-HOME-PRESENT')
        if n == 16:
            categories = ''
            case('T10-MISSING-DEVICE')
        if n == 17:
            group, categories = 'HSI Boston Users,HSI Boston Reviewers', ''
            case('T09-MULTI-GROUP-SAME-ORG')
        if n == 18:
            group, categories = 'HSI Boston Users,ERO Buffalo Users', ''
            case('T09-MULTI-GROUP-CONFLICT')
        if n == 19:
            group, categories = 'Mock Unmapped Users', ''
            case('T09-UNMAPPED-GROUP')
        if n == 20:
            status, categories = 'Active', ''
            upload = datetime.combine(as_of - timedelta(days=2), time(16), UTC)
            case('T12-ACTIVE-FUTURE-DELETE')
        if n == 21:
            status, categories = 'Queued for Deletion', ''
            case('T11-QUEUED-STATUS')
        if 22 <= n <= 27:
            kind = list(CONTENT)[n - 22]
            categories = ''
            case('T11-TYPE-' + kind.upper().replace(' ', '-'))
        if n == 28:
            categories = ''
            case('T08-ZERO-NUMERICS')
        if n == 29:
            categories = ''
            case('T08-Y-FLAGS')
        if n == 30:
            categories = ''
            case('T08-SHARE-COUNTS')
        if n == 31:
            categories = ''
            case('T08-COMPACT-VIEWED-TIMESTAMP')
        if n == 32:
            kind, categories = 'Document', ''
            case('T10-OPTIONAL-END-DATE')
        if n == 33:
            categories = ''
            case('T01-CUSTOM-FIELDS')
        if n == 34:
            categories = ''
            case('T08-UNICODE-TEXT')
        start = upload - delay
        duration = round(rng.uniform(10, 600), 3) if kind in {'Video', 'Audio'} else 0.0
        if n == 28:
            duration = 0.0
        size = round(rng.uniform(0.01, 350), 7) if n != 28 else 0.0
        device_number = 1 + (n - 1) % 100
        device_serial = ('T19M' if kind == 'Firing Log' else 'D01M') + f'{device_number:05d}'
        row.update({
            'Evidence ID': uid(seed, f'evidence-{n}'), 'Status': status,
            'Title': f'MOCK {kind} {start.astimezone(NY):%Y-%m-%d %H%M} {device_serial}',
            'External ID': f'MOCK-EXT-{n:06d}' if n % 7 == 0 else '',
            'Description': 'Synthetic fixture record; no media exists.' if n % 9 == 0 else '',
            'Evidence Group': '', 'Date Uploaded': fmt(upload),
            'Date Modified': fmt(upload + timedelta(minutes=1)),
            'Created Date (Record Start)': fmt(start),
            'Date (Record End)': fmt(start + timedelta(seconds=duration)) if kind in {'Video', 'Audio'} else '',
            'Date Deleted': fmt(upload + timedelta(days=180)) if n % 5 == 0 else '',
            'Days Between Create and Upload Date': str(int(delay.total_seconds() // 86400)),
            'Evidence Type': kind, 'Flag (Y/N)': 'Y' if n == 29 else 'N',
            'Content Type': CONTENT[kind], 'Size (MB)': str(size), 'Duration (seconds)': str(duration),
            'Owner Rank': 'MOCK Rank' if owner % 20 == 0 else '',
            'Owner First Name': f'MockGiven{owner:03d}', 'Owner Last Name': f'TestOwner{owner:03d}',
            'Owner Badge ID': f'MOCK{owner:06d}', 'Owner Role': ROLES[(owner - 1) % len(ROLES)],
            'Owner Groups': group, 'Latitude': '38.00000000', 'Longitude': "'-97.00000000",
            'Device ID': uid(seed, f'device-{device_serial}'), 'Serial Number': device_serial,
            'Notes': 'Mock fixture only.', 'Categories': categories, 'Tags': ','.join(tags),
            'Cases': f'MOCK-CASE-{n:06d}' if n % 17 == 0 else '',
            'View Count': '5' if n % 3 == 0 else '0',
            'Last Viewed On': (upload + timedelta(minutes=3)).astimezone(NY).strftime('%Y%m%dT%H%M%S%z') if n % 3 == 0 or n == 31 else '',
            'Reassigned (Y/N)': 'Y' if n == 30 else 'N',
            'Authenticated Share Count': '2' if n == 30 else '0', 'Download Count': '3' if n == 30 else '0',
            'Checksum': '{sha2}' + hashlib.sha256(f'MOCK-NO-MEDIA:{seed}:{n}'.encode()).hexdigest().upper(),
            'Restricted (Y/N)': 'Y' if n == 29 else 'N', 'Evidence Serial Number': f'M{n:05d}',
            'axon.evidenceDeviceHomeId': uid(seed, 'home-' + (group or 'unknown')),
            'axon.evidenceDeviceHomeName': group.removesuffix(' Users') if group and ',' not in group else 'MOCK Device Home',
        })
        for prefix in ['Updated By', 'Uploaded By']:
            if prefix == 'Uploaded By' or n % 8 == 0:
                for suffix in ['Rank', 'First Name', 'Last Name', 'Badge ID', 'Role']:
                    row[f'{prefix} {suffix}'] = row[f'Owner {suffix}']
        for name in ['Evidence Internal ACL Users', 'Evidence Internal ACL Groups', 'Evidence External ACL Users', 'Evidence External ACL Groups', 'Evidence Partner Agencies', 'Case Partner Agencies']:
            row[name] = ' '
        if n == 13:
            row['Notes'] = 'MOCK value with comma, "quoted text"\nSecond line of synthetic notes.'
        if n == 14:
            for key in ['Owner Rank', 'Owner First Name', 'Owner Last Name', 'Owner Badge ID', 'Owner Role']:
                row[key] = ''
        if n == 15:
            row['axon.evidenceDeviceHomeName'] = 'MOCK Home Without Owner Group'
        if n == 16:
            for key in ['Device ID', 'Serial Number', 'axon.evidenceDeviceHomeId', 'axon.evidenceDeviceHomeName']:
                row[key] = ''
        if n == 28:
            for key in ['Size (MB)', 'Duration (seconds)', 'View Count', 'Authenticated Share Count', 'Download Count']:
                row[key] = '0'
        if n == 33:
            for key in ['hsi_incident_number', 'icm_case_number', 'eagle_event_number', 'icm_op_plan_number', 'sen_number', 'foia_case_number']:
                row[key] = f'MOCK-{key.upper()}-000033'
        if n == 34:
            row['Owner First Name'], row['Owner Last Name'] = 'Mock Élodie', 'Test O’Example'
        rows.append(row)
    return rows, anchors


def report_rows(raw, as_of):
    output, expected = [], []
    for n, row in enumerate(raw, 1):
        org, reason = resolve_org(row['Owner Groups'])
        age = (as_of - datetime.fromisoformat(row['Date Uploaded']).astimezone(UTC).date()).days
        included = not row['Categories'].strip()
        expected.append({'CSV Record': n, 'Evidence ID': row['Evidence ID'], 'Evidence Serial Number': row['Evidence Serial Number'], 'Included': 'Y' if included else 'N', 'Days Past Due': age, 'Age Band': '>30' if age > 30 else '15-30' if age >= 15 else '<15', 'Component': org[0], 'Component Name': org[1], 'AOR': org[2], 'Mapping Result': reason, 'Scenario Tags': row['Tags']})
        if included:
            out = dict(row)
            out.update({'Days Past Due': age, 'ID': '', 'Component': org[0], 'Component Name': org[1], 'AOR': org[2]})
            for key in ['Created Date (Record Start)', 'Date Uploaded']:
                out[key] = datetime.fromisoformat(row[key]).astimezone(UTC).date().isoformat()
            out['Days Between Create and Upload Date'] = int(row['Days Between Create and Upload Date'])
            output.append(out)
    return sorted(output, key=lambda r: (-r['Days Past Due'], r['Evidence Serial Number'])), expected


def style_sheet(ws, detail=False):
    ws.freeze_panes = 'A2'
    ws.auto_filter.ref = ws.dimensions
    ws.sheet_view.showGridLines = False
    ws.print_title_rows = '1:1'
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.paperSize = ws.PAPERSIZE_A3
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToWidth, ws.page_setup.fitToHeight = 1, 0
    ws.oddFooter.center.text = 'SYNTHETIC TEST DATA | Page &P of &N'
    for row in ws:
        ws.row_dimensions[row[0].row].height = 30
        for c in row:
            c.font = Font(name='Arial', size=10, color='172B4D')
            c.alignment = Alignment(vertical='top', wrap_text=True)
    for c in ws[1]:
        c.fill = PatternFill('solid', fgColor='17365D')
        c.font = Font(name='Arial', size=10, color='FFFFFF', bold=True)
    ws.row_dimensions[1].height = 46
    for c in ws[1]:
        name = str(c.value)
        ws.column_dimensions[get_column_letter(c.column)].width = 35 if 'Groups' in name or name in ['Component', 'Component Name', 'AOR'] else 25 if 'Date' in name or 'Number' in name else 22
    if detail:
        for row in ws.iter_rows(min_row=2):
            age = row[0].value
            color = 'F4CCCC' if age > 30 else 'FCE5CD' if age >= 15 else 'FFF2CC'
            row[0].fill = PatternFill('solid', fgColor=color)
            row[0].font = Font(name='Arial', size=10, bold=True, color='7F0000' if age > 30 else '172B4D')


def make_report(schema, detail, as_of, target):
    wb = Workbook()
    wb.remove(wb.active)
    stamp = datetime.combine(as_of, time(12), UTC).replace(tzinfo=None)
    wb.properties.creator = 'Mock Evidence Fixture Generator'
    wb.properties.title = 'SYNTHETIC Uncategorized Report'
    wb.properties.description = 'Synthetic fixture; no actual evidence or operational categorization instructions.'
    wb.properties.created = stamp
    wb.properties.modified = stamp
    for title in schema['sheet_order']:
        ws = wb.create_sheet(title)
        if title == 'Instructions':
            values = [
                ['', 'Key for the Uncategorized Report.', 'Categorized Timeline Requirement'],
                [' ', '1. Red: critically overdue mock records (greater than 30 days).', 'Critical test band'],
                [' ', '2. Orange: overdue mock records (15-30 days inclusive).', 'Overdue test band'],
                [' ', '3. Yellow: mock records less than 15 days old, including age zero.', 'Recent test band'],
                ['', '', ''], [f'Report Created: {as_of}', '', ''], [f'Current Data From: {as_of}', '', ''],
                ['', '', ''], ['SYNTHETIC TEST DATA', 'Invented identities, identifiers, and record metadata. No media exists.', 'Generated for data source testing.'],
                ['Mock aging rule', 'Report as-of date minus UTC calendar date of Date Uploaded. No grace period.', 'Fixture rule; not an approved production policy.'],
                ['Mock inclusion rule', 'Trim Categories; include empty or whitespace-only values. Both supplied status values are retained; all six evidence types count.', 'No status or type filter.'],
                ['Day 30', 'Included only in the 15-30 band. Both >30 sheets use strictly greater than 30.', 'The source workbook used inconsistent day-30 thresholds; this mock resolves them consistently.'],
                ['Organization mapping', 'Use only mock-organization-crosswalk.csv. Blank, unknown, or conflicting groups leave all organization fields blank. No device-home fallback.', 'Multiple groups mapping to one organization count once.'],
                ['Blank groups in rollups', 'AOR and Component Name total sheets exclude blank keys. Age-band AOR sheets include blank keys. >30 Component sheet excludes blank keys.', 'Matches observed blank handling.'],
                ['Identity and duplicates', 'Report ID is blank. Main CSV has unique Evidence IDs and serials. Separate duplicate fixtures reject the later record.', 'Duplicate policy applies only to this test pack.'],
                ['Owner summary', 'Group by the seven displayed owner/organization columns, retaining blank values; count every included record once.', 'Expected LEO total equals main detail total.'],
                ['Dates / upload delay', 'Report dates are UTC YYYY-MM-DD strings. Upload delay is floor of elapsed timestamp duration in 24-hour days.', 'Raw timestamps retain America/New_York offsets.'],
                ['Summary headings', 'Original summary headers containing Videos are retained for format compatibility; totals include all evidence types.', 'Exact source tabs and data headers retained.'],
                ['Static output', 'This report is a saved expected-result snapshot. Regenerate it after changing CSV inputs or mock rules.', 'Use the included generator and verifier.'],
                ['Reference date', str(as_of), 'Frozen for repeatable age tests; not the current date.'],
            ]
            for row in values:
                ws.append(row)
            style_sheet(ws)
            ws.auto_filter.ref = None
            for col, width in [('A', 43), ('B', 118), ('C', 85)]:
                ws.column_dimensions[col].width = width
            for r in range(1, ws.max_row + 1):
                ws.row_dimensions[r].height = 42
            for r, color in [(2, 'F4CCCC'), (3, 'FCE5CD'), (4, 'FFF2CC')]:
                ws.cell(r, 1).fill = PatternFill('solid', fgColor=color)
            ws['A9'].font = Font(name='Arial', size=12, color='9C0006', bold=True)
            continue
        heads = schema['sheet_headers'][title]
        ws.append(heads)
        if 'Days Past Due' in heads:
            component = {'HSI Uncat #s': 'HSI', 'ERO Uncat #s': 'ERO', 'FLETC Uncat #s': 'FLETC', 'FOIA Uncat #s': 'FOIA', 'OPR Uncat #s': 'Office of Professional Responsibility', 'OFTP Uncat #s': 'Office of Firearms and Tactical Programs', 'Blanks Uncat #s': ''}.get(title)
            selected = detail if title == 'Days Past Due' else [r for r in detail if r['Component'] == component]
            for row in selected:
                ws.append([row[h] for h in heads])
            style_sheet(ws, detail=True)
        elif title == 'LEO Uncat #s':
            group_heads = heads[1:]
            counts = Counter(tuple(r[h] for h in group_heads) for r in detail)
            for key, total in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])):
                ws.append([total, *key])
            style_sheet(ws)
        else:
            group = heads[0]
            chosen = detail
            if title.startswith('> 30'):
                chosen = [r for r in chosen if r['Days Past Due'] > 30]
            elif title.startswith('15 - 30'):
                chosen = [r for r in chosen if 15 <= r['Days Past Due'] <= 30]
            elif title.startswith('< 15'):
                chosen = [r for r in chosen if r['Days Past Due'] < 15]
            keep_blank = title in ['> 30 Days Uncat #s', '15 - 30 Days Uncat #s', '< 15 Days Uncat #s']
            counts = Counter(r[group] for r in chosen if keep_blank or r[group])
            for key, total in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])):
                ws.append([key, total])
            style_sheet(ws)
    wb.save(target)


def make_test_inputs(schema, rows, out):
    fields = schema['csv_headers']
    tests = []
    cases = [
        ('invalid_timestamp.csv', 'Date Uploaded', 'not-a-timestamp', 'INVALID_DATE_UPLOADED'),
        ('invalid_numeric.csv', 'Size (MB)', 'not-a-number', 'INVALID_SIZE_MB'),
        ('missing_evidence_id.csv', 'Evidence ID', '', 'MISSING_EVIDENCE_ID'),
        ('duplicate_evidence_id.csv', 'Evidence ID', rows[0]['Evidence ID'], 'DUPLICATE_EVIDENCE_ID'),
        ('duplicate_evidence_serial.csv', 'Evidence Serial Number', rows[0]['Evidence Serial Number'], 'DUPLICATE_EVIDENCE_SERIAL'),
    ]
    for name, field, value, error in cases:
        pair = [dict(rows[0]), dict(rows[1])]
        pair[1][field] = value
        write_csv(out / name, fields, pair)
        tests.append({'file': name, 'populated_records': 2, 'accepted_records': 1, 'rejected_records': 1, 'error': error, 'rejected_csv_records': [2]})
    no_category = [h for h in fields if h != 'Categories']
    write_csv(out / 'missing_required_header.csv', no_category, [{h: r[h] for h in no_category} for r in rows[:2]])
    tests.append({'file': 'missing_required_header.csv', 'populated_records': 2, 'accepted_records': 0, 'rejected_records': 0, 'error': 'SCHEMA_MISMATCH', 'rejected_csv_records': [], 'file_rejected': True})
    write_csv(out / 'padded_valid_input.csv', fields, rows, padding=40)
    tests.append({'file': 'padded_valid_input.csv', 'populated_records': len(rows), 'empty_records': 40, 'accepted_records': len(rows), 'rejected_records': 0, 'error': None, 'rejected_csv_records': []})
    (out / 'expectations.json').write_text(json.dumps(tests, indent=2) + '\n')


def scenarios(anchors, size):
    rows = [
        ('T01', 'Exact schema / custom fields', 'reports.evidenceCreated_mock.csv; schema.json', anchors['T01-CUSTOM-FIELDS'], '70 exact headers in order; custom dotted names and optional custom values preserved.'),
        ('T02', 'Entirely blank padding', 'test-inputs/padded_valid_input.csv', '', f'{size} populated records plus 40 empty records; same expected report as the main CSV.'),
        ('T03', 'Category filter', 'reports.evidenceCreated_mock.csv', anchors['T03-WHITESPACE-CATEGORY'], 'Empty and whitespace Categories included; populated categories excluded, including multiple categories.'),
        ('T04', 'CSV quoting', 'reports.evidenceCreated_mock.csv', anchors['T04-QUOTES-NEWLINE'], 'Quoted notes contain comma, double quotes, and a newline. Parse CSV records, not physical lines.'),
        ('T05', 'Age boundaries', 'reports.evidenceCreated_mock.csv', ','.join(anchors[f'T05-DAY-{a}'] for a in [0, 14, 15, 29, 30, 31]), '0/14 recent; 15/29/30 overdue; 31 critical. Component and AOR thresholds agree.'),
        ('T06', 'UTC midnight', 'reports.evidenceCreated_mock.csv', anchors['T06-UTC-MIDNIGHT'], 'Local upload day differs from UTC upload day; expected UTC age is 2.'),
        ('T07', 'Upload delay', 'reports.evidenceCreated_mock.csv', ','.join(anchors[k] for k in ['T07-DELAYED-UPLOAD', 'T07-SAME-DAY', 'T07-CROSS-MIDNIGHT']), '45-day delay floors to 45; same-day and 1-hour midnight crossing floor to 0.'),
        ('T08', 'Numeric / text / flags', 'reports.evidenceCreated_mock.csv', ','.join(anchors[k] for k in ['T08-ZERO-NUMERICS', 'T08-Y-FLAGS', 'T08-SHARE-COUNTS', 'T08-COMPACT-VIEWED-TIMESTAMP', 'T08-UNICODE-TEXT']), 'Decimals, zero counts, apostrophe longitude, Y flags, compact viewed timestamps, Unicode names, and text IDs parse correctly.'),
        ('T09', 'Missing and multiple owner groups', 'reports.evidenceCreated_mock.csv; mock-organization-crosswalk.csv', ','.join(anchors[k] for k in ['T09-MISSING-OWNER', 'T09-BLANK-GROUP-HOME-PRESENT', 'T09-MULTI-GROUP-SAME-ORG', 'T09-MULTI-GROUP-CONFLICT', 'T09-UNMAPPED-GROUP']), 'Blank owner retained; same-organization multi-group maps once; missing, conflicting, or unmapped groups produce blank organization fields.'),
        ('T10', 'Optional device / end date', 'reports.evidenceCreated_mock.csv', ','.join(anchors[k] for k in ['T10-MISSING-DEVICE', 'T10-OPTIONAL-END-DATE']), 'Missing device values and static evidence with no end date remain included.'),
        ('T11', 'Evidence types and statuses', 'reports.evidenceCreated_mock.csv', ','.join(anchors[k] for k in anchors if k.startswith('T11-')), 'All six evidence types and both Active / Queued for Deletion appear in uncategorized detail.'),
        ('T12', 'Future deletion metadata', 'reports.evidenceCreated_mock.csv', anchors['T12-ACTIVE-FUTURE-DELETE'], 'Active record with future Date Deleted remains Active and appears in the report.'),
        ('T13', 'Duplicate identifiers', 'test-inputs/duplicate_evidence_id.csv; test-inputs/duplicate_evidence_serial.csv', '', 'Separate two-record inputs: accept the first, reject the second with a specific duplicate error. Neither is appended to the main CSV.'),
        ('T14', 'Rollup reconciliation', 'Uncategorized Report Mock Data.xlsx; record-expectations.csv', '', 'LEO and age-band totals equal detail total. Nonblank-key rollups exclude blanks explicitly. Off records have no dedicated original detail tab.'),
        ('T15', 'Invalid inputs', 'test-inputs/invalid_timestamp.csv; test-inputs/invalid_numeric.csv; test-inputs/missing_evidence_id.csv; test-inputs/missing_required_header.csv', '', 'Reject only the malformed record in each valid-schema file; reject the entire missing-header file before row processing.'),
        ('T16', 'Deterministic generation', 'generate_mock_data.py; verify_mock_data.py', '', f'Default {size} records; fixed seed and as-of date. Repeated generation gives identical CSV bytes and report cell values.'),
    ]
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--rows', type=int, default=1000)
    parser.add_argument('--seed', type=int, default=20261022)
    parser.add_argument('--as-of', type=date.fromisoformat, default=date(2026, 4, 27))
    parser.add_argument('--out-dir', type=Path, default=HERE)
    args = parser.parse_args()
    if not 40 <= args.rows <= 99999:
        parser.error('--rows must be between 40 and 99999 to retain scenario anchors and six-character evidence serials.')
    out = args.out_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    schema = json.loads((HERE / 'schema.json').read_text())
    if out != HERE:
        shutil.copyfile(HERE / 'schema.json', out / 'schema.json')
    rows, anchors = make_records(schema, args.rows, args.seed, args.as_of)
    detail, expected = report_rows(rows, args.as_of)
    write_csv(out / 'reports.evidenceCreated_mock.csv', schema['csv_headers'], rows)
    write_csv(out / 'record-expectations.csv', list(expected[0]), expected)
    write_csv(out / 'mock-organization-crosswalk.csv', ['Owner Group', 'Component', 'Component Name', 'AOR'], [dict(zip(['Owner Group', 'Component', 'Component Name', 'AOR'], r)) for r in ORG_ROWS])
    make_report(schema, detail, args.as_of, out / 'Uncategorized Report Mock Data.xlsx')
    make_test_inputs(schema, rows, out / 'test-inputs')
    sh = ['Test ID', 'Scenario', 'Files', 'Anchor Evidence Serials', 'Expected behavior']
    write_csv(out / 'test-scenarios.csv', sh, [dict(zip(sh, row)) for row in scenarios(anchors, args.rows)])
    config = {'synthetic': True, 'rows': args.rows, 'seed': args.seed, 'as_of': str(args.as_of), 'timezone_for_raw_timestamps': 'America/New_York', 'report_date_timezone': 'UTC', 'aging_days': 'as_of minus UTC calendar date of Date Uploaded; no grace period', 'report_id': 'blank for source-format compatibility', 'bands': {'recent': '0 <= days < 15', 'overdue': '15 <= days <= 30', 'critical': 'days > 30'}, 'source_sha256': schema['source_sha256'], 'anchors': anchors}
    (out / 'fixture-config.json').write_text(json.dumps(config, indent=2) + '\n')
    print(json.dumps({'output': str(out), 'raw_records': len(rows), 'uncategorized_records': len(detail), 'categorized_records': len(rows) - len(detail), 'age_bands': dict(Counter('>30' if r['Days Past Due'] > 30 else '15-30' if r['Days Past Due'] >= 15 else '<15' for r in detail))}, indent=2))


if __name__ == '__main__':
    main()
